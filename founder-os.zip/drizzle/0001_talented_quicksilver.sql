CREATE TABLE `dashboardSummary` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int NOT NULL,
	`weeklyFocus` text,
	`currentPriorities` text,
	`mvpProgressPercentage` int DEFAULT 0,
	`activeSubscriptionsCount` int DEFAULT 0,
	`upcomingTrialExpirations` int DEFAULT 0,
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `dashboardSummary_id` PRIMARY KEY(`id`),
	CONSTRAINT `dashboardSummary_userId_unique` UNIQUE(`userId`)
);
--> statement-breakpoint
CREATE TABLE `learningResources` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int NOT NULL,
	`title` varchar(255) NOT NULL,
	`resourceType` enum('Paid Course','Free Course','YouTube','Research') NOT NULL,
	`category` enum('GoHighLevel','Lovable','Supabase','Automation','SaaS Architecture','Databases','APIs','UI/UX','Zapier','Make') NOT NULL,
	`status` enum('Not Started','In Progress','Completed') NOT NULL DEFAULT 'Not Started',
	`completionPercentage` int DEFAULT 0,
	`priority` enum('Low','Medium','High') DEFAULT 'Medium',
	`url` varchar(500),
	`notes` text,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `learningResources_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `prompts` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int NOT NULL,
	`title` varchar(255) NOT NULL,
	`category` enum('Manus','ChatGPT','Lovable','Zapier','Make','GoHighLevel') NOT NULL,
	`promptText` text NOT NULL,
	`tags` varchar(500),
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `prompts_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `roadmapFeatures` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int NOT NULL,
	`featureName` varchar(255) NOT NULL,
	`description` text,
	`mvpPriority` enum('Critical','High','Medium','Low') DEFAULT 'Medium',
	`status` enum('Not Started','In Progress','Completed') NOT NULL DEFAULT 'Not Started',
	`complexity` enum('Low','Medium','High') DEFAULT 'Medium',
	`notes` text,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `roadmapFeatures_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `studySessions` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int NOT NULL,
	`dayOfWeek` enum('Monday','Tuesday','Wednesday','Thursday','Friday') NOT NULL,
	`startTime` varchar(5) NOT NULL,
	`endTime` varchar(5) NOT NULL,
	`subject` varchar(255) NOT NULL,
	`status` enum('Scheduled','In Progress','Completed','Skipped') NOT NULL DEFAULT 'Scheduled',
	`notes` text,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `studySessions_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `subscriptions` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int NOT NULL,
	`toolName` varchar(255) NOT NULL,
	`category` varchar(100) NOT NULL,
	`status` enum('Active','Trial','Deferred','Cancelled') NOT NULL DEFAULT 'Active',
	`monthlyCost` decimal(10,2) DEFAULT '0',
	`trialStartDate` date,
	`trialEndDate` date,
	`renewalDate` date,
	`loginEmail` varchar(320),
	`continueOrCancel` enum('Continue','Cancel','Undecided') DEFAULT 'Undecided',
	`notes` text,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `subscriptions_id` PRIMARY KEY(`id`)
);
