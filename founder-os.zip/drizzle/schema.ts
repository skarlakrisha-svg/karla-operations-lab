import { int, mysqlEnum, mysqlTable, text, timestamp, varchar, json, boolean, date, decimal } from "drizzle-orm/mysql-core";

/**
 * Core user table backing auth flow.
 * Extend this file with additional tables as your product grows.
 * Columns use camelCase to match both database fields and generated types.
 */
export const users = mysqlTable("users", {
  /**
   * Surrogate primary key. Auto-incremented numeric value managed by the database.
   * Use this for relations between tables.
   */
  id: int("id").autoincrement().primaryKey(),
  /** Manus OAuth identifier (openId) returned from the OAuth callback. Unique per user. */
  openId: varchar("openId", { length: 64 }).notNull().unique(),
  name: text("name"),
  email: varchar("email", { length: 320 }),
  loginMethod: varchar("loginMethod", { length: 64 }),
  role: mysqlEnum("role", ["user", "admin"]).default("user").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  lastSignedIn: timestamp("lastSignedIn").defaultNow().notNull(),
});

export type User = typeof users.$inferSelect;
export type InsertUser = typeof users.$inferInsert;

/**
 * Subscriptions/Tools Tracker
 */
export const subscriptions = mysqlTable("subscriptions", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  toolName: varchar("toolName", { length: 255 }).notNull(),
  category: varchar("category", { length: 100 }).notNull(),
  status: mysqlEnum("status", ["Active", "Trial", "Deferred", "Cancelled"]).default("Active").notNull(),
  monthlyCost: decimal("monthlyCost", { precision: 10, scale: 2 }).default("0"),
  trialStartDate: date("trialStartDate"),
  trialEndDate: date("trialEndDate"),
  renewalDate: date("renewalDate"),
  loginEmail: varchar("loginEmail", { length: 320 }),
  continueOrCancel: mysqlEnum("continueOrCancel", ["Continue", "Cancel", "Undecided"]).default("Undecided"),
  notes: text("notes"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type Subscription = typeof subscriptions.$inferSelect;
export type InsertSubscription = typeof subscriptions.$inferInsert;

/**
 * Learning Hub - Courses, tutorials, research
 */
export const learningResources = mysqlTable("learningResources", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  title: varchar("title", { length: 255 }).notNull(),
  resourceType: mysqlEnum("resourceType", ["Paid Course", "Free Course", "YouTube", "Research"]).notNull(),
  category: mysqlEnum("category", ["GoHighLevel", "Lovable", "Supabase", "Automation", "SaaS Architecture", "Databases", "APIs", "UI/UX", "Zapier", "Make"]).notNull(),
  status: mysqlEnum("status", ["Not Started", "In Progress", "Completed"]).default("Not Started").notNull(),
  completionPercentage: int("completionPercentage").default(0),
  priority: mysqlEnum("priority", ["Low", "Medium", "High"]).default("Medium"),
  url: varchar("url", { length: 500 }),
  notes: text("notes"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type LearningResource = typeof learningResources.$inferSelect;
export type InsertLearningResource = typeof learningResources.$inferInsert;

/**
 * Property Management SaaS Roadmap
 */
export const roadmapFeatures = mysqlTable("roadmapFeatures", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  featureName: varchar("featureName", { length: 255 }).notNull(),
  description: text("description"),
  mvpPriority: mysqlEnum("mvpPriority", ["Critical", "High", "Medium", "Low"]).default("Medium"),
  status: mysqlEnum("status", ["Not Started", "In Progress", "Completed"]).default("Not Started").notNull(),
  complexity: mysqlEnum("complexity", ["Low", "Medium", "High"]).default("Medium"),
  notes: text("notes"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type RoadmapFeature = typeof roadmapFeatures.$inferSelect;
export type InsertRoadmapFeature = typeof roadmapFeatures.$inferInsert;

/**
 * Prompt Library
 */
export const prompts = mysqlTable("prompts", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  title: varchar("title", { length: 255 }).notNull(),
  category: mysqlEnum("category", ["Manus", "ChatGPT", "Lovable", "Zapier", "Make", "GoHighLevel"]).notNull(),
  promptText: text("promptText").notNull(),
  tags: varchar("tags", { length: 500 }),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type Prompt = typeof prompts.$inferSelect;
export type InsertPrompt = typeof prompts.$inferInsert;

/**
 * Weekly Study Planner
 */
export const studySessions = mysqlTable("studySessions", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  dayOfWeek: mysqlEnum("dayOfWeek", ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday"]).notNull(),
  startTime: varchar("startTime", { length: 5 }).notNull(), // HH:MM format
  endTime: varchar("endTime", { length: 5 }).notNull(), // HH:MM format
  subject: varchar("subject", { length: 255 }).notNull(),
  status: mysqlEnum("status", ["Scheduled", "In Progress", "Completed", "Skipped"]).default("Scheduled").notNull(),
  notes: text("notes"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type StudySession = typeof studySessions.$inferSelect;
export type InsertStudySession = typeof studySessions.$inferInsert;

/**
 * Dashboard Summary - Cached data for quick dashboard loads
 */
export const dashboardSummary = mysqlTable("dashboardSummary", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull().unique(),
  weeklyFocus: text("weeklyFocus"),
  currentPriorities: text("currentPriorities"),
  mvpProgressPercentage: int("mvpProgressPercentage").default(0),
  activeSubscriptionsCount: int("activeSubscriptionsCount").default(0),
  upcomingTrialExpirations: int("upcomingTrialExpirations").default(0),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type DashboardSummary = typeof dashboardSummary.$inferSelect;
export type InsertDashboardSummary = typeof dashboardSummary.$inferInsert;

/**
 * Learning Phases - Interactive learning modules for each phase
 */
export const learningPhases = mysqlTable("learningPhases", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  phaseNumber: int("phaseNumber").notNull(), // 1-5
  title: varchar("title", { length: 255 }).notNull(),
  description: text("description"),
  topics: text("topics"), // JSON array of topics
  goals: text("goals"), // JSON array of goals
  keyConceptsContent: text("keyConceptsContent"), // AI-generated content
  learningOutline: text("learningOutline"), // AI-generated structured outline
  status: mysqlEnum("status", ["Not Started", "In Progress", "Completed"]).default("Not Started").notNull(),
  completionPercentage: int("completionPercentage").default(0),
  startedAt: timestamp("startedAt"),
  completedAt: timestamp("completedAt"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type LearningPhase = typeof learningPhases.$inferSelect;
export type InsertLearningPhase = typeof learningPhases.$inferInsert;

/**
 * Phase Resources - Video links and external resources per phase
 */
export const phaseResources = mysqlTable("phaseResources", {
  id: int("id").autoincrement().primaryKey(),
  phaseId: int("phaseId").notNull(),
  userId: int("userId").notNull(),
  resourceType: mysqlEnum("resourceType", ["Video", "Article", "Link", "Document"]).notNull(),
  title: varchar("title", { length: 255 }).notNull(),
  url: varchar("url", { length: 500 }).notNull(),
  description: text("description"),
  duration: int("duration"), // in minutes for videos
  addedAt: timestamp("addedAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type PhaseResource = typeof phaseResources.$inferSelect;
export type InsertPhaseResource = typeof phaseResources.$inferInsert;

/**
 * Phase Notes - User notes and reflection per phase
 */
export const phaseNotes = mysqlTable("phaseNotes", {
  id: int("id").autoincrement().primaryKey(),
  phaseId: int("phaseId").notNull(),
  userId: int("userId").notNull(),
  personalNotes: text("personalNotes"), // User's own notes
  whatILearned: text("whatILearned"), // Reflection prompt
  keyTakeaways: text("keyTakeaways"), // Reflection prompt
  whatToRevisit: text("whatToRevisit"), // Reflection prompt
  customReflections: text("customReflections"), // JSON for additional reflection fields
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type PhaseNote = typeof phaseNotes.$inferSelect;
export type InsertPhaseNote = typeof phaseNotes.$inferInsert;

/**
 * Phase Progress - Track time spent and progress per phase
 */
export const phaseProgress = mysqlTable("phaseProgress", {
  id: int("id").autoincrement().primaryKey(),
  phaseId: int("phaseId").notNull(),
  userId: int("userId").notNull(),
  status: mysqlEnum("status", ["Not Started", "In Progress", "Completed"]).default("Not Started").notNull(),
  completionPercentage: int("completionPercentage").default(0),
  timeSpentMinutes: int("timeSpentMinutes").default(0),
  resourcesAdded: int("resourcesAdded").default(0),
  notesCount: int("notesCount").default(0),
  estimatedTimeMinutes: int("estimatedTimeMinutes").default(0), // Estimated time to complete
  startedAt: timestamp("startedAt"),
  completedAt: timestamp("completedAt"),
  lastAccessedAt: timestamp("lastAccessedAt"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type PhaseProgress = typeof phaseProgress.$inferSelect;
export type InsertPhaseProgress = typeof phaseProgress.$inferInsert;


/**
 * Phase Certificates - Track earned certificates
 */
export const phaseCertificates = mysqlTable("phaseCertificates", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  phaseId: int("phaseId").notNull(),
  certificateId: varchar("certificateId", { length: 64 }).notNull().unique(),
  completionDate: timestamp("completionDate").defaultNow().notNull(),
  certificateUrl: text("certificateUrl"),
  downloadUrl: text("downloadUrl"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type PhaseCertificate = typeof phaseCertificates.$inferSelect;
export type InsertPhaseCertificate = typeof phaseCertificates.$inferInsert;

/**
 * Phase Quizzes - Store quiz questions and metadata
 */
export const phaseQuizzes = mysqlTable("phaseQuizzes", {
  id: int("id").autoincrement().primaryKey(),
  phaseId: int("phaseId").notNull(),
  quizTitle: varchar("quizTitle", { length: 255 }).notNull(),
  description: text("description"),
  questions: json("questions").$type<Array<{
    id: string;
    question: string;
    options: string[];
    correctAnswer: number;
    explanation: string;
  }>>().notNull(),
  passingScore: int("passingScore").default(70),
  timeLimit: int("timeLimit"), // in minutes
  isRequired: boolean("isRequired").default(false),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type PhaseQuiz = typeof phaseQuizzes.$inferSelect;
export type InsertPhaseQuiz = typeof phaseQuizzes.$inferInsert;

/**
 * User Quiz Attempts - Track quiz performance
 */
export const userQuizAttempts = mysqlTable("userQuizAttempts", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  quizId: int("quizId").notNull(),
  score: int("score").notNull(),
  percentage: int("percentage").notNull(),
  answers: json("answers").$type<Record<string, number>>().notNull(),
  passed: boolean("passed").notNull(),
  timeSpentSeconds: int("timeSpentSeconds"),
  attemptedAt: timestamp("attemptedAt").defaultNow().notNull(),
});

export type UserQuizAttempt = typeof userQuizAttempts.$inferSelect;
export type InsertUserQuizAttempt = typeof userQuizAttempts.$inferInsert;

/**
 * Learning Community - Track users in learning phases
 */
export const learningCommunity = mysqlTable("learningCommunity", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  phaseId: int("phaseId").notNull(),
  username: varchar("username", { length: 255 }).notNull(),
  role: mysqlEnum("role", ["student", "mentor", "instructor"]).default("student").notNull(),
  points: int("points").default(0),
  joinedAt: timestamp("joinedAt").defaultNow().notNull(),
});

export type LearningCommunityMember = typeof learningCommunity.$inferSelect;
export type InsertLearningCommunityMember = typeof learningCommunity.$inferInsert;

/**
 * Discussion Threads - Community discussion topics
 */
export const discussionThreads = mysqlTable("discussionThreads", {
  id: int("id").autoincrement().primaryKey(),
  phaseId: int("phaseId").notNull(),
  threadTitle: varchar("threadTitle", { length: 255 }).notNull(),
  description: text("description"),
  createdBy: int("createdBy").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  lastActivityAt: timestamp("lastActivityAt").defaultNow().notNull(),
  replyCount: int("replyCount").default(0),
  viewCount: int("viewCount").default(0),
  isResolved: boolean("isResolved").default(false),
});

export type DiscussionThread = typeof discussionThreads.$inferSelect;
export type InsertDiscussionThread = typeof discussionThreads.$inferInsert;

/**
 * Thread Replies - Responses to discussion threads
 */
export const threadReplies = mysqlTable("threadReplies", {
  id: int("id").autoincrement().primaryKey(),
  threadId: int("threadId").notNull(),
  userId: int("userId").notNull(),
  content: text("content").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  likes: int("likes").default(0),
  isAnswer: boolean("isAnswer").default(false),
  isHelpful: boolean("isHelpful").default(false),
});

export type ThreadReply = typeof threadReplies.$inferSelect;
export type InsertThreadReply = typeof threadReplies.$inferInsert;

/**
 * User Achievements/Badges - Track badges and achievements
 */
export const userAchievements = mysqlTable("userAchievements", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  badgeType: mysqlEnum("badgeType", [
    "first_phase_complete",
    "all_phases_complete",
    "quiz_master",
    "helpful_contributor",
    "community_leader",
    "perfect_score",
    "streak_7_days",
    "streak_30_days",
  ]).notNull(),
  earnedAt: timestamp("earnedAt").defaultNow().notNull(),
});

export type UserAchievement = typeof userAchievements.$inferSelect;
export type InsertUserAchievement = typeof userAchievements.$inferInsert;
