CREATE TABLE `discussionThreads` (
	`id` int AUTO_INCREMENT NOT NULL,
	`phaseId` int NOT NULL,
	`threadTitle` varchar(255) NOT NULL,
	`description` text,
	`createdBy` int NOT NULL,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`lastActivityAt` timestamp NOT NULL DEFAULT (now()),
	`replyCount` int DEFAULT 0,
	`viewCount` int DEFAULT 0,
	`isResolved` boolean DEFAULT false,
	CONSTRAINT `discussionThreads_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `learningCommunity` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int NOT NULL,
	`phaseId` int NOT NULL,
	`username` varchar(255) NOT NULL,
	`role` enum('student','mentor','instructor') NOT NULL DEFAULT 'student',
	`points` int DEFAULT 0,
	`joinedAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `learningCommunity_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `phaseCertificates` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int NOT NULL,
	`phaseId` int NOT NULL,
	`certificateId` varchar(64) NOT NULL,
	`completionDate` timestamp NOT NULL DEFAULT (now()),
	`certificateUrl` text,
	`downloadUrl` text,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `phaseCertificates_id` PRIMARY KEY(`id`),
	CONSTRAINT `phaseCertificates_certificateId_unique` UNIQUE(`certificateId`)
);
--> statement-breakpoint
CREATE TABLE `phaseQuizzes` (
	`id` int AUTO_INCREMENT NOT NULL,
	`phaseId` int NOT NULL,
	`quizTitle` varchar(255) NOT NULL,
	`description` text,
	`questions` json NOT NULL,
	`passingScore` int DEFAULT 70,
	`timeLimit` int,
	`isRequired` boolean DEFAULT false,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `phaseQuizzes_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `threadReplies` (
	`id` int AUTO_INCREMENT NOT NULL,
	`threadId` int NOT NULL,
	`userId` int NOT NULL,
	`content` text NOT NULL,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	`likes` int DEFAULT 0,
	`isAnswer` boolean DEFAULT false,
	`isHelpful` boolean DEFAULT false,
	CONSTRAINT `threadReplies_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `userAchievements` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int NOT NULL,
	`badgeType` enum('first_phase_complete','all_phases_complete','quiz_master','helpful_contributor','community_leader','perfect_score','streak_7_days','streak_30_days') NOT NULL,
	`earnedAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `userAchievements_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `userQuizAttempts` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int NOT NULL,
	`quizId` int NOT NULL,
	`score` int NOT NULL,
	`percentage` int NOT NULL,
	`answers` json NOT NULL,
	`passed` boolean NOT NULL,
	`timeSpentSeconds` int,
	`attemptedAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `userQuizAttempts_id` PRIMARY KEY(`id`)
);
