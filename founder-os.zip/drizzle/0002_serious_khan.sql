CREATE TABLE `learningPhases` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int NOT NULL,
	`phaseNumber` int NOT NULL,
	`title` varchar(255) NOT NULL,
	`description` text,
	`topics` text,
	`goals` text,
	`keyConceptsContent` text,
	`learningOutline` text,
	`status` enum('Not Started','In Progress','Completed') NOT NULL DEFAULT 'Not Started',
	`completionPercentage` int DEFAULT 0,
	`startedAt` timestamp,
	`completedAt` timestamp,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `learningPhases_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `phaseNotes` (
	`id` int AUTO_INCREMENT NOT NULL,
	`phaseId` int NOT NULL,
	`userId` int NOT NULL,
	`personalNotes` text,
	`whatILearned` text,
	`keyTakeaways` text,
	`whatToRevisit` text,
	`customReflections` text,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `phaseNotes_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `phaseProgress` (
	`id` int AUTO_INCREMENT NOT NULL,
	`phaseId` int NOT NULL,
	`userId` int NOT NULL,
	`status` enum('Not Started','In Progress','Completed') NOT NULL DEFAULT 'Not Started',
	`completionPercentage` int DEFAULT 0,
	`timeSpentMinutes` int DEFAULT 0,
	`resourcesAdded` int DEFAULT 0,
	`notesCount` int DEFAULT 0,
	`estimatedTimeMinutes` int DEFAULT 0,
	`startedAt` timestamp,
	`completedAt` timestamp,
	`lastAccessedAt` timestamp,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `phaseProgress_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `phaseResources` (
	`id` int AUTO_INCREMENT NOT NULL,
	`phaseId` int NOT NULL,
	`userId` int NOT NULL,
	`resourceType` enum('Video','Article','Link','Document') NOT NULL,
	`title` varchar(255) NOT NULL,
	`url` varchar(500) NOT NULL,
	`description` text,
	`duration` int,
	`addedAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `phaseResources_id` PRIMARY KEY(`id`)
);
