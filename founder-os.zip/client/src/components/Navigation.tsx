import { useLocation } from "wouter";
import { useAuth } from "@/_core/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { LayoutDashboard, BookOpen, Zap, Map, MessageSquare, Calendar, Award, HelpCircle, Users, LogOut } from "lucide-react";
import { getLoginUrl } from "@/const";
import { useTheme } from "@/contexts/ThemeContext";
import { cn } from "@/lib/utils";

const navItems = [
  { path: "/", icon: LayoutDashboard, label: "Dashboard", id: "dashboard" },
  { path: "/learning-roadmap", icon: BookOpen, label: "Learning Roadmap", id: "learning-roadmap" },
  { path: "/tools", icon: Zap, label: "Tools", id: "tools" },
  { path: "/roadmap", icon: Map, label: "Roadmap", id: "roadmap" },
  { path: "/vault", icon: MessageSquare, label: "Vault", id: "vault" },
  { path: "/planner", icon: Calendar, label: "Planner", id: "planner" },
  { path: "/certificates", icon: Award, label: "Certs", id: "certificates" },
  { path: "/quizzes", icon: HelpCircle, label: "Quizzes", id: "quizzes" },
  { path: "/community", icon: Users, label: "Community", id: "community" },
];

export function DesktopNav() {
  const [location] = useLocation();
  const { user, logout } = useAuth();
  const { theme, toggleTheme } = useTheme();

  return (
    <aside className="hidden lg:flex flex-col w-64 bg-card border-r border-border fixed left-0 top-0 h-screen z-50">
      <div className="p-6 border-b border-border">
        <h1 className="text-2xl font-bold text-accent">KS Motion OS</h1>
      </div>

      <nav className="flex-1 overflow-y-auto p-4 space-y-2">
        {navItems.map((item) => {
          const Icon = item.icon;
          const isActive = location === item.path;
          return (
            <a
              key={item.id}
              href={item.path}
              className={cn(
                "flex items-center gap-3 px-4 py-3 rounded-lg transition-all duration-200",
                isActive
                  ? "bg-accent/10 text-accent font-medium"
                  : "text-muted-foreground hover:text-foreground hover:bg-muted"
              )}
            >
              <Icon className="w-5 h-5" />
              <span>{item.label}</span>
            </a>
          );
        })}
      </nav>

      <div className="p-4 border-t border-border space-y-2">
        <button
          onClick={toggleTheme}
          className="w-full flex items-center gap-3 px-4 py-3 rounded-lg text-muted-foreground hover:text-foreground hover:bg-muted transition-all duration-200"
        >
          {theme === "dark" ? "☀️" : "🌙"} Theme
        </button>
        {user && (
          <button
            onClick={logout}
            className="w-full flex items-center gap-3 px-4 py-3 rounded-lg text-muted-foreground hover:text-foreground hover:bg-muted transition-all duration-200"
          >
            <LogOut className="w-5 h-5" />
            Logout
          </button>
        )}
      </div>
    </aside>
  );
}

export function MobileNav() {
  const [location] = useLocation();
  const { isAuthenticated } = useAuth();

  if (!isAuthenticated) {
    return null;
  }

  return (
    <nav className="lg:hidden fixed bottom-0 left-0 right-0 bg-card border-t border-border z-50 h-auto">
      <div className="flex items-center justify-start overflow-x-auto px-2 py-3 gap-2 scrollbar-hide">
        {navItems.map((item) => {
          const Icon = item.icon;
          const isActive = location === item.path;
          return (
            <a
              key={item.id}
              href={item.path}
              className={cn(
                "flex flex-col items-center justify-center gap-1 px-3 py-2 rounded-lg transition-all duration-200 whitespace-nowrap flex-shrink-0 min-w-fit",
                isActive
                  ? "text-accent bg-accent/10"
                  : "text-muted-foreground hover:text-foreground"
              )}
            >
              <Icon className="w-4 h-4" />
              <span className="text-xs font-medium">{item.label}</span>
            </a>
          );
        })}
      </div>
    </nav>
  );
}

export function MainLayout({ children }: { children: React.ReactNode }) {
  const { isAuthenticated, loading } = useAuth();
  const { theme, toggleTheme } = useTheme();
  const { user, logout } = useAuth();

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="text-center">
          <div className="w-8 h-8 border-4 border-accent border-t-transparent rounded-full animate-spin mx-auto mb-4"></div>
          <p className="text-muted-foreground">Loading...</p>
        </div>
      </div>
    );
  }

  if (!isAuthenticated) {
    return (
      <div className="flex items-center justify-center min-h-screen bg-background">
        <div className="text-center max-w-md px-4">
          <h1 className="text-4xl font-bold text-accent mb-4">KS Motion OS</h1>
          <p className="text-foreground mb-8">Your centralized learning roadmap, SaaS build tracker, and founder knowledge hub</p>
          <a href={getLoginUrl()}>
            <Button size="lg" className="w-full">
              Sign In with Manus
            </Button>
          </a>
        </div>
      </div>
    );
  }

  return (
    <div className="flex flex-col lg:flex-row min-h-screen bg-background">
      <DesktopNav />
      
      {/* Mobile Header */}
      <header className="lg:hidden fixed top-0 left-0 right-0 bg-card border-b border-border z-40 h-14">
        <div className="flex items-center justify-between h-full px-4">
          <h1 className="text-base font-bold text-accent truncate">KS Motion OS</h1>
          <div className="flex items-center gap-2">
            <button
              onClick={toggleTheme}
              className="p-2 hover:bg-muted rounded-lg transition-colors"
              title="Toggle theme"
            >
              {theme === "dark" ? "☀️" : "🌙"}
            </button>
            {user && (
              <button
                onClick={logout}
                className="p-2 hover:bg-muted rounded-lg transition-colors"
                title="Logout"
              >
                <LogOut className="w-4 h-4" />
              </button>
            )}
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="flex-1 lg:ml-64 pt-14 lg:pt-0 pb-24 lg:pb-0 overflow-x-hidden w-full">
        {children}
      </main>

      {/* Mobile Bottom Navigation */}
      <MobileNav />
    </div>
  );
}
