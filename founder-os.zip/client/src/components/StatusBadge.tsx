import { cn } from "@/lib/utils";

type StatusType = "Active" | "Trial" | "Deferred" | "Cancelled" | "Completed" | "In Progress" | "Not Started" | "Scheduled" | "Skipped" | "Critical" | "High" | "Medium" | "Low";

interface StatusBadgeProps {
  status: StatusType;
  className?: string;
}

const statusStyles: Record<StatusType, string> = {
  // Subscription statuses
  "Active": "status-active",
  "Trial": "status-trial",
  "Deferred": "status-deferred",
  "Cancelled": "status-cancelled",

  // Learning/Roadmap statuses
  "Completed": "status-completed",
  "In Progress": "status-in-progress",
  "Not Started": "status-not-started",

  // Study session statuses
  "Scheduled": "status-not-started",
  "Skipped": "status-cancelled",

  // Priority/Complexity levels
  "Critical": "bg-destructive/10 text-destructive border-destructive/30",
  "High": "bg-accent/10 text-accent border-accent/30",
  "Medium": "bg-blue-500/10 text-blue-600 dark:text-blue-400 border-blue-500/30",
  "Low": "bg-muted text-muted-foreground border-border",
};

export function StatusBadge({ status, className }: StatusBadgeProps) {
  return (
    <span className={cn("status-badge", statusStyles[status], className)}>
      {status}
    </span>
  );
}
