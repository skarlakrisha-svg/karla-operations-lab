import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { ChevronDown, ChevronUp, ArrowRight } from "lucide-react";
import { useState } from "react";
import { useLocation } from "wouter";

interface Phase {
  id: number;
  name: string;
  priority: "Critical" | "High" | "Medium" | "Later";
  topics: string[];
  goals: string[];
}

const phases: Phase[] = [
  {
    id: 1,
    name: "Foundation",
    priority: "Critical",
    topics: [
      "ChatGPT fundamentals",
      "Manus fundamentals",
      "Lovable fundamentals",
      "SaaS concepts",
      "UI/UX basics",
      "Dashboard structure",
      "Founder workflow systems",
      "MVP concepts",
    ],
    goals: [
      "Understand SaaS structure",
      "Build first internal apps",
      "Learn dashboard organization",
      "Understand frontend concepts",
    ],
  },
  {
    id: 2,
    name: "Backend & Databases",
    priority: "High",
    topics: [
      "Supabase fundamentals",
      "Databases",
      "Authentication",
      "Tables and relationships",
      "File uploads",
      "Backend concepts",
      "APIs basics",
    ],
    goals: [
      "Understand app backend logic",
      "Learn how data is stored",
      "Learn user authentication systems",
    ],
  },
  {
    id: 3,
    name: "Automation",
    priority: "High",
    topics: [
      "Zapier basics",
      "Make fundamentals",
      "Workflow logic",
      "Triggers and actions",
      "Automation architecture",
      "Notifications",
      "CRM automations",
    ],
    goals: [
      "Build automation workflows",
      "Understand system connections",
      "Learn operational automations",
    ],
  },
  {
    id: 4,
    name: "Business Operations",
    priority: "Medium",
    topics: [
      "GoHighLevel",
      "CRM systems",
      "Sales pipelines",
      "Lead tracking",
      "Client onboarding",
      "Automations for agencies",
    ],
    goals: [
      "Learn business operations systems",
      "Understand CRM workflows",
      "Build scalable operational systems",
    ],
  },
  {
    id: 5,
    name: "Advanced Systems",
    priority: "Later",
    topics: [
      "OpenAI API",
      "AI integrations",
      "Cursor",
      "n8n",
      "Advanced backend architecture",
      "AI agents",
    ],
    goals: [
      "Add AI features",
      "Build advanced SaaS systems",
      "Create scalable automations",
    ],
  },
];

const priorityColors: Record<string, string> = {
  Critical: "bg-destructive/10 text-destructive border-destructive/30",
  High: "bg-accent/10 text-accent border-accent/30",
  Medium: "bg-blue-500/10 text-blue-600 dark:text-blue-400 border-blue-500/30",
  Later: "bg-muted text-muted-foreground border-border",
};

function PhaseActionButton({ phaseId, phaseName }: { phaseId: number; phaseName: string }) {
  const [, navigate] = useLocation();
  return (
    <Button
      className="w-full gap-2"
      onClick={() => navigate(`/phase/${phaseId}`)}
    >
      Start Phase {phaseId} — {phaseName}
      <ArrowRight className="w-4 h-4" />
    </Button>
  );
}

export default function LearningRoadmap() {
  const [expandedPhase, setExpandedPhase] = useState<number | null>(1);

  return (
    <div className="p-4 lg:p-8 space-y-6">
      {/* Header */}
      <div>
        <h1 className="text-3xl font-bold text-foreground">Learning Roadmap</h1>
        <p className="text-muted-foreground mt-1">
          Your structured learning path from foundation to advanced systems. Follow these phases to build a complete understanding of SaaS development and automation.
        </p>
      </div>

      {/* Phases */}
      <div className="space-y-4">
        {phases.map((phase) => (
          <Card
            key={phase.id}
            className="card-premium p-6 cursor-pointer transition-all duration-200 hover:border-accent/50"
            onClick={() => setExpandedPhase(expandedPhase === phase.id ? null : phase.id)}
          >
            {/* Phase Header */}
            <div className="flex items-start justify-between mb-4">
              <div className="flex-1">
                <div className="flex items-center gap-3 mb-2">
                  <h2 className="text-2xl font-bold text-foreground">
                    Phase {phase.id} — {phase.name}
                  </h2>
                  <Badge className={`status-badge ${priorityColors[phase.priority]}`}>
                    {phase.priority}
                  </Badge>
                </div>
                <p className="text-sm text-muted-foreground">
                  {phase.id === 1 && "Start here: Build your foundation in core tools and concepts"}
                  {phase.id === 2 && "Learn backend systems and data management"}
                  {phase.id === 3 && "Master workflow automation and system connections"}
                  {phase.id === 4 && "Understand business operations and CRM systems"}
                  {phase.id === 5 && "Explore advanced AI and automation capabilities"}
                </p>
              </div>
              <button className="p-2 hover:bg-muted rounded-lg transition-colors">
                {expandedPhase === phase.id ? (
                  <ChevronUp className="w-5 h-5" />
                ) : (
                  <ChevronDown className="w-5 h-5" />
                )}
              </button>
            </div>

            {/* Expanded Content */}
            {expandedPhase === phase.id && (
              <div className="space-y-6 pt-4 border-t border-border">
                {/* Topics */}
                <div>
                  <h3 className="font-semibold text-foreground mb-3">Topics to Learn</h3>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-2">
                    {phase.topics.map((topic, idx) => (
                      <div
                        key={idx}
                        className="flex items-center gap-2 p-3 rounded-lg bg-muted/50 border border-border"
                      >
                        <div className="w-2 h-2 rounded-full bg-accent flex-shrink-0"></div>
                        <span className="text-sm text-foreground">{topic}</span>
                      </div>
                    ))}
                  </div>
                </div>

                {/* Goals */}
                <div>
                  <h3 className="font-semibold text-foreground mb-3">Learning Goals</h3>
                  <div className="space-y-2">
                    {phase.goals.map((goal, idx) => (
                      <div
                        key={idx}
                        className="flex items-start gap-3 p-3 rounded-lg bg-accent/5 border border-accent/20"
                      >
                        <div className="w-5 h-5 rounded-full bg-accent text-white flex items-center justify-center text-xs font-bold flex-shrink-0 mt-0.5">
                          ✓
                        </div>
                        <span className="text-sm text-foreground">{goal}</span>
                      </div>
                    ))}
                  </div>
                </div>

                {/* Action Button */}
                <PhaseActionButton phaseId={phase.id} phaseName={phase.name} />
              </div>
            )}
          </Card>
        ))}
      </div>

      {/* Progress Summary */}
      <Card className="card-premium p-6">
        <h2 className="text-lg font-bold text-foreground mb-4">Your Learning Journey</h2>
        <div className="space-y-3">
          <p className="text-sm text-muted-foreground">
            This roadmap is designed to take you from complete beginner to advanced SaaS builder. Each phase builds on the previous one, so follow them in order for the best results.
          </p>
          <div className="flex items-center gap-2 text-sm">
            <div className="w-3 h-3 rounded-full bg-accent"></div>
            <span className="text-foreground">Estimated total time: 3-6 months depending on your pace</span>
          </div>
          <div className="flex items-center gap-2 text-sm">
            <div className="w-3 h-3 rounded-full bg-accent"></div>
            <span className="text-foreground">Recommended: 5-10 hours per week</span>
          </div>
        </div>
      </Card>
    </div>
  );
}
