import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Plus, Trash2, Edit2, Zap } from "lucide-react";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useState } from "react";
import { toast } from "sonner";

interface RoadmapFeature {
  id: string;
  name: string;
  description: string;
  complexity: "Low" | "Medium" | "High";
  priority: "MVP" | "Phase 2";
  status: "Not Started" | "In Progress" | "Completed";
  notes?: string;
}

const mvpFeatures: RoadmapFeature[] = [
  {
    id: "1",
    name: "Tenant Dashboard",
    description: "Self-service portal for tenants to view lease info, pay rent, and submit requests",
    complexity: "High",
    priority: "MVP",
    status: "In Progress",
    notes: "Core feature for tenant engagement",
  },
  {
    id: "2",
    name: "Landlord Dashboard",
    description: "Management interface for landlords to view properties, tenants, and payments",
    complexity: "High",
    priority: "MVP",
    status: "In Progress",
    notes: "Primary landlord interface",
  },
  {
    id: "3",
    name: "Admin Dashboard",
    description: "Administrative interface for system management and reporting",
    complexity: "Medium",
    priority: "MVP",
    status: "Not Started",
    notes: "For platform admins",
  },
  {
    id: "4",
    name: "Payment Proof Uploads",
    description: "Tenants can upload proof of payment for rent",
    complexity: "Medium",
    priority: "MVP",
    status: "Not Started",
    notes: "Critical for payment verification",
  },
  {
    id: "5",
    name: "Onboarding Toolkit",
    description: "Automated onboarding workflows for new tenants and landlords",
    complexity: "High",
    priority: "MVP",
    status: "Not Started",
    notes: "Reduces manual setup work",
  },
  {
    id: "6",
    name: "Leasing Toolkit",
    description: "Templates and tools for lease creation and management",
    complexity: "Medium",
    priority: "MVP",
    status: "Not Started",
    notes: "Streamlines leasing process",
  },
  {
    id: "7",
    name: "Documents",
    description: "Document storage and management for leases, agreements, and records",
    complexity: "Medium",
    priority: "MVP",
    status: "Not Started",
    notes: "Centralized document hub",
  },
  {
    id: "8",
    name: "Maintenance Requests",
    description: "System for tenants to submit and track maintenance requests",
    complexity: "Medium",
    priority: "MVP",
    status: "Not Started",
    notes: "Improves tenant satisfaction",
  },
];

const phase2Features: RoadmapFeature[] = [
  {
    id: "9",
    name: "AI Assistant",
    description: "AI-powered chatbot for tenant support and FAQs",
    complexity: "High",
    priority: "Phase 2",
    status: "Not Started",
    notes: "Reduces support burden",
  },
  {
    id: "10",
    name: "Automated Reminders",
    description: "Automated SMS/email reminders for rent due dates and maintenance",
    complexity: "Medium",
    priority: "Phase 2",
    status: "Not Started",
    notes: "Improves payment compliance",
  },
  {
    id: "11",
    name: "CRM Integration",
    description: "Integration with GoHighLevel for lead tracking and management",
    complexity: "High",
    priority: "Phase 2",
    status: "Not Started",
    notes: "Enables sales automation",
  },
  {
    id: "12",
    name: "Tenant Messaging",
    description: "In-app messaging system between tenants and landlords",
    complexity: "Medium",
    priority: "Phase 2",
    status: "Not Started",
    notes: "Improves communication",
  },
  {
    id: "13",
    name: "Smart Workflows",
    description: "Automated workflows for common property management tasks",
    complexity: "High",
    priority: "Phase 2",
    status: "Not Started",
    notes: "Reduces manual work",
  },
  {
    id: "14",
    name: "Analytics",
    description: "Comprehensive analytics and reporting dashboard",
    complexity: "High",
    priority: "Phase 2",
    status: "Not Started",
    notes: "Data-driven insights",
  },
];

const complexityColors: Record<string, string> = {
  Low: "bg-green-500/10 text-green-600 dark:text-green-400 border-green-500/30",
  Medium: "bg-blue-500/10 text-blue-600 dark:text-blue-400 border-blue-500/30",
  High: "bg-destructive/10 text-destructive border-destructive/30",
};

const statusColors: Record<string, string> = {
  "Not Started": "bg-muted text-muted-foreground",
  "In Progress": "bg-accent/10 text-accent",
  "Completed": "bg-green-500/10 text-green-600 dark:text-green-400",
};

function FeatureCard({ feature, onEdit, onDelete }: { feature: RoadmapFeature; onEdit: (f: RoadmapFeature) => void; onDelete: (id: string) => void }) {
  return (
    <Card className="card-premium p-5">
      <div className="flex items-start justify-between mb-3">
        <div className="flex-1">
          <h3 className="font-bold text-foreground text-lg">{feature.name}</h3>
          <p className="text-sm text-muted-foreground mt-1">{feature.description}</p>
        </div>
        <div className="flex gap-1 ml-2">
          <Button size="sm" variant="outline" onClick={() => onEdit(feature)}>
            <Edit2 className="w-4 h-4" />
          </Button>
          <Button size="sm" variant="outline" onClick={() => onDelete(feature.id)}>
            <Trash2 className="w-4 h-4" />
          </Button>
        </div>
      </div>

      <div className="flex gap-2 flex-wrap">
        <Badge className={`status-badge ${statusColors[feature.status]}`}>
          {feature.status}
        </Badge>
        <Badge className={`status-badge ${complexityColors[feature.complexity]}`}>
          {feature.complexity} Complexity
        </Badge>
      </div>

      {feature.notes && (
        <p className="text-xs text-muted-foreground mt-3 pt-3 border-t border-border">
          <strong>Notes:</strong> {feature.notes}
        </p>
      )}
    </Card>
  );
}

export default function Roadmap() {
  const [mvpList, setMvpList] = useState(mvpFeatures);
  const [phase2List, setPhase2List] = useState(phase2Features);
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [editingFeature, setEditingFeature] = useState<RoadmapFeature | null>(null);
  const [editingPhase, setEditingPhase] = useState<"mvp" | "phase2">("mvp");

  const handleEdit = (feature: RoadmapFeature, phase: "mvp" | "phase2") => {
    setEditingFeature(feature);
    setEditingPhase(phase);
    setIsDialogOpen(true);
  };

  const handleDelete = (id: string, phase: "mvp" | "phase2") => {
    if (confirm("Are you sure you want to delete this feature?")) {
      if (phase === "mvp") {
        setMvpList(mvpList.filter(f => f.id !== id));
      } else {
        setPhase2List(phase2List.filter(f => f.id !== id));
      }
      toast.success("Feature deleted");
    }
  };

  const handleAddNew = (phase: "mvp" | "phase2") => {
    setEditingFeature(null);
    setEditingPhase(phase);
    setIsDialogOpen(true);
  };

  const mvpProgress = Math.round((mvpList.filter(f => f.status === "Completed").length / mvpList.length) * 100);
  const totalFeatures = mvpList.length + phase2List.length;
  const completedFeatures = mvpList.filter(f => f.status === "Completed").length + phase2List.filter(f => f.status === "Completed").length;

  return (
    <div className="p-4 lg:p-8 space-y-8">
      {/* Header */}
      <div>
        <h1 className="text-3xl font-bold text-foreground">Property Management SaaS Roadmap</h1>
        <p className="text-muted-foreground mt-1">
          Your complete product roadmap organized into MVP and Phase 2 features. Track complexity, priority, and progress.
        </p>
      </div>

      {/* Progress Overview */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <Card className="card-premium p-6">
          <p className="text-sm text-muted-foreground font-medium">Total Features</p>
          <p className="text-3xl font-bold text-accent mt-2">{totalFeatures}</p>
          <p className="text-xs text-muted-foreground mt-1">MVP: {mvpList.length} | Phase 2: {phase2List.length}</p>
        </Card>
        <Card className="card-premium p-6">
          <p className="text-sm text-muted-foreground font-medium">Completed</p>
          <p className="text-3xl font-bold text-green-500 mt-2">{completedFeatures}</p>
          <p className="text-xs text-muted-foreground mt-1">{Math.round((completedFeatures / totalFeatures) * 100)}% progress</p>
        </Card>
        <Card className="card-premium p-6">
          <p className="text-sm text-muted-foreground font-medium">MVP Status</p>
          <p className="text-3xl font-bold text-accent mt-2">{mvpProgress}%</p>
          <p className="text-xs text-muted-foreground mt-1">{mvpList.filter(f => f.status === "In Progress").length} in progress</p>
        </Card>
      </div>

      {/* MVP Features */}
      <div>
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center gap-2">
            <Zap className="w-6 h-6 text-accent" />
            <h2 className="text-2xl font-bold text-foreground">MVP Features</h2>
            <Badge className="bg-accent/10 text-accent border-accent/30">Priority</Badge>
          </div>
          <Dialog open={isDialogOpen && editingPhase === "mvp"} onOpenChange={setIsDialogOpen}>
            <DialogTrigger asChild>
              <Button onClick={() => handleAddNew("mvp")}>
                <Plus className="w-4 h-4 mr-2" />
                Add Feature
              </Button>
            </DialogTrigger>
            <DialogContent className="max-w-2xl">
              <DialogHeader>
                <DialogTitle>Add MVP Feature</DialogTitle>
              </DialogHeader>
              <div className="space-y-4">
                <div>
                  <Label>Feature Name</Label>
                  <Input placeholder="Feature name" className="mt-1" />
                </div>
                <div>
                  <Label>Description</Label>
                  <Textarea placeholder="What does this feature do?" className="mt-1" />
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <Label>Complexity</Label>
                    <Select defaultValue="Medium">
                      <SelectTrigger className="mt-1">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="Low">Low</SelectItem>
                        <SelectItem value="Medium">Medium</SelectItem>
                        <SelectItem value="High">High</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <div>
                    <Label>Status</Label>
                    <Select defaultValue="Not Started">
                      <SelectTrigger className="mt-1">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="Not Started">Not Started</SelectItem>
                        <SelectItem value="In Progress">In Progress</SelectItem>
                        <SelectItem value="Completed">Completed</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>
                <div>
                  <Label>Notes</Label>
                  <Textarea placeholder="Additional notes..." className="mt-1" />
                </div>
                <Button className="w-full">Save Feature</Button>
              </div>
            </DialogContent>
          </Dialog>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {mvpList.map((feature) => (
            <FeatureCard
              key={feature.id}
              feature={feature}
              onEdit={(f) => handleEdit(f, "mvp")}
              onDelete={(id) => handleDelete(id, "mvp")}
            />
          ))}
        </div>
      </div>

      {/* Phase 2 Features */}
      <div>
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center gap-2">
            <Zap className="w-6 h-6 text-blue-500" />
            <h2 className="text-2xl font-bold text-foreground">Phase 2 Features</h2>
            <Badge className="bg-blue-500/10 text-blue-600 dark:text-blue-400 border-blue-500/30">Future</Badge>
          </div>
          <Dialog open={isDialogOpen && editingPhase === "phase2"} onOpenChange={setIsDialogOpen}>
            <DialogTrigger asChild>
              <Button onClick={() => handleAddNew("phase2")}>
                <Plus className="w-4 h-4 mr-2" />
                Add Feature
              </Button>
            </DialogTrigger>
            <DialogContent className="max-w-2xl">
              <DialogHeader>
                <DialogTitle>Add Phase 2 Feature</DialogTitle>
              </DialogHeader>
              <div className="space-y-4">
                <div>
                  <Label>Feature Name</Label>
                  <Input placeholder="Feature name" className="mt-1" />
                </div>
                <div>
                  <Label>Description</Label>
                  <Textarea placeholder="What does this feature do?" className="mt-1" />
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <Label>Complexity</Label>
                    <Select defaultValue="Medium">
                      <SelectTrigger className="mt-1">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="Low">Low</SelectItem>
                        <SelectItem value="Medium">Medium</SelectItem>
                        <SelectItem value="High">High</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <div>
                    <Label>Status</Label>
                    <Select defaultValue="Not Started">
                      <SelectTrigger className="mt-1">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="Not Started">Not Started</SelectItem>
                        <SelectItem value="In Progress">In Progress</SelectItem>
                        <SelectItem value="Completed">Completed</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>
                <div>
                  <Label>Notes</Label>
                  <Textarea placeholder="Additional notes..." className="mt-1" />
                </div>
                <Button className="w-full">Save Feature</Button>
              </div>
            </DialogContent>
          </Dialog>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {phase2List.map((feature) => (
            <FeatureCard
              key={feature.id}
              feature={feature}
              onEdit={(f) => handleEdit(f, "phase2")}
              onDelete={(id) => handleDelete(id, "phase2")}
            />
          ))}
        </div>
      </div>

      {/* Development Tips */}
      <Card className="card-premium p-6 bg-accent/5 border-accent/20">
        <h3 className="text-lg font-bold text-foreground mb-3">🎯 Development Strategy</h3>
        <ul className="space-y-2 text-sm text-foreground">
          <li>✓ Focus on MVP features first to get a working product to market</li>
          <li>✓ Prioritize high-complexity features early to identify blockers</li>
          <li>✓ Phase 2 features can be built after MVP launch based on user feedback</li>
          <li>✓ Track complexity to estimate development time and resource allocation</li>
          <li>✓ Update status regularly to maintain visibility into progress</li>
        </ul>
      </Card>
    </div>
  );
}
