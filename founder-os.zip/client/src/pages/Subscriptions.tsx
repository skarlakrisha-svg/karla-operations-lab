import { trpc } from "@/lib/trpc";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Textarea } from "@/components/ui/textarea";
import { StatusBadge } from "@/components/StatusBadge";
import { Plus, Trash2, Edit2 } from "lucide-react";
import { useState } from "react";
import { toast } from "sonner";

const INITIAL_TOOLS = [
  { toolName: "Manus", category: "Productivity", status: "Active" },
  { toolName: "ChatGPT", category: "AI", status: "Active" },
  { toolName: "Lovable", category: "Development", status: "Active" },
  { toolName: "Supabase", category: "Backend", status: "Active" },
  { toolName: "Zapier", category: "Automation", status: "Active" },
  { toolName: "Make", category: "Automation", status: "Active" },
  { toolName: "GoHighLevel", category: "Marketing", status: "Active" },
  { toolName: "GitHub", category: "Development", status: "Active" },
  { toolName: "Vercel", category: "Deployment", status: "Active" },
  { toolName: "OpenAI API", category: "AI", status: "Active" },
  { toolName: "Claude", category: "AI", status: "Deferred" },
  { toolName: "Cursor", category: "Development", status: "Deferred" },
  { toolName: "n8n", category: "Automation", status: "Deferred" },
];

interface FormData {
  toolName: string;
  category: string;
  status: string;
  monthlyCost: string;
  trialStartDate: string;
  trialEndDate: string;
  renewalDate: string;
  loginEmail: string;
  continueOrCancel: string;
  notes: string;
}

export default function Subscriptions() {
  const { data: subscriptions = [], isLoading, refetch } = trpc.subscriptions.list.useQuery();
  const createMutation = trpc.subscriptions.create.useMutation({
    onSuccess: () => {
      toast.success("Subscription added");
      refetch();
      resetForm();
      setIsDialogOpen(false);
    },
  });
  const updateMutation = trpc.subscriptions.update.useMutation({
    onSuccess: () => {
      toast.success("Subscription updated");
      refetch();
      resetForm();
      setIsDialogOpen(false);
    },
  });
  const deleteMutation = trpc.subscriptions.delete.useMutation({
    onSuccess: () => {
      toast.success("Subscription deleted");
      refetch();
    },
  });

  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [editingId, setEditingId] = useState<number | null>(null);
  const [formData, setFormData] = useState<FormData>({
    toolName: "",
    category: "",
    status: "Active",
    monthlyCost: "",
    trialStartDate: "",
    trialEndDate: "",
    renewalDate: "",
    loginEmail: "",
    continueOrCancel: "Undecided",
    notes: "",
  });

  const resetForm = () => {
    setFormData({
      toolName: "",
      category: "",
      status: "Active",
      monthlyCost: "",
      trialStartDate: "",
      trialEndDate: "",
      renewalDate: "",
      loginEmail: "",
      continueOrCancel: "Undecided",
      notes: "",
    });
    setEditingId(null);
  };

  const handleOpenDialog = (subscription?: any) => {
    if (subscription) {
      setEditingId(subscription.id);
      setFormData({
        toolName: subscription.toolName,
        category: subscription.category,
        status: subscription.status,
        monthlyCost: subscription.monthlyCost || "",
        trialStartDate: subscription.trialStartDate ? subscription.trialStartDate.split("T")[0] : "",
        trialEndDate: subscription.trialEndDate ? subscription.trialEndDate.split("T")[0] : "",
        renewalDate: subscription.renewalDate ? subscription.renewalDate.split("T")[0] : "",
        loginEmail: subscription.loginEmail || "",
        continueOrCancel: subscription.continueOrCancel || "Undecided",
        notes: subscription.notes || "",
      });
    } else {
      resetForm();
    }
    setIsDialogOpen(true);
  };

  const handleSave = () => {
    if (!formData.toolName.trim()) {
      toast.error("Tool name is required");
      return;
    }

    if (editingId) {
      updateMutation.mutate({
        id: editingId,
        ...formData,
      });
    } else {
      createMutation.mutate(formData);
    }
  };

  const handleDelete = (id: number) => {
    if (confirm("Are you sure you want to delete this subscription?")) {
      deleteMutation.mutate({ id });
    }
  };

  const handleSeedData = async () => {
    for (const tool of INITIAL_TOOLS) {
      if (!subscriptions.find(s => s.toolName === tool.toolName)) {
        await createMutation.mutateAsync(tool);
      }
    }
    toast.success("Pre-seeded tools added");
  };

  if (isLoading) {
    return (
      <div className="p-4 lg:p-8">
        <div className="space-y-4">
          {[1, 2, 3].map((i) => (
            <div key={i} className="h-24 bg-muted rounded-lg animate-pulse" />
          ))}
        </div>
      </div>
    );
  }

  return (
    <div className="p-4 lg:p-8 space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-foreground">Tool & Subscription Tracker</h1>
          <p className="text-muted-foreground mt-1">Manage all your tools, costs, and trial dates in one place.</p>
        </div>
        <div className="flex gap-2">
          {subscriptions.length === 0 && (
            <Button onClick={handleSeedData} variant="outline">
              Seed Sample Data
            </Button>
          )}
          <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
            <DialogTrigger asChild>
              <Button onClick={() => handleOpenDialog()}>
                <Plus className="w-4 h-4 mr-2" />
                Add Subscription
              </Button>
            </DialogTrigger>
            <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
              <DialogHeader>
                <DialogTitle>{editingId ? "Edit Subscription" : "Add New Subscription"}</DialogTitle>
              </DialogHeader>
              <div className="space-y-4">
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <Label htmlFor="toolName">Tool Name *</Label>
                    <Input
                      id="toolName"
                      value={formData.toolName}
                      onChange={(e) => setFormData({ ...formData, toolName: e.target.value })}
                      placeholder="e.g., ChatGPT"
                      className="mt-1"
                    />
                  </div>
                  <div>
                    <Label htmlFor="category">Category</Label>
                    <Input
                      id="category"
                      value={formData.category}
                      onChange={(e) => setFormData({ ...formData, category: e.target.value })}
                      placeholder="e.g., AI"
                      className="mt-1"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <Label htmlFor="status">Status</Label>
                    <Select value={formData.status} onValueChange={(value) => setFormData({ ...formData, status: value })}>
                      <SelectTrigger className="mt-1">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="Active">Active</SelectItem>
                        <SelectItem value="Trial">Trial</SelectItem>
                        <SelectItem value="Deferred">Deferred</SelectItem>
                        <SelectItem value="Cancelled">Cancelled</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <div>
                    <Label htmlFor="monthlyCost">Monthly Cost ($)</Label>
                    <Input
                      id="monthlyCost"
                      type="number"
                      step="0.01"
                      value={formData.monthlyCost}
                      onChange={(e) => setFormData({ ...formData, monthlyCost: e.target.value })}
                      placeholder="0.00"
                      className="mt-1"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <Label htmlFor="trialStartDate">Trial Start Date</Label>
                    <Input
                      id="trialStartDate"
                      type="date"
                      value={formData.trialStartDate}
                      onChange={(e) => setFormData({ ...formData, trialStartDate: e.target.value })}
                      className="mt-1"
                    />
                  </div>
                  <div>
                    <Label htmlFor="trialEndDate">Trial End Date</Label>
                    <Input
                      id="trialEndDate"
                      type="date"
                      value={formData.trialEndDate}
                      onChange={(e) => setFormData({ ...formData, trialEndDate: e.target.value })}
                      className="mt-1"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <Label htmlFor="renewalDate">Renewal Date</Label>
                    <Input
                      id="renewalDate"
                      type="date"
                      value={formData.renewalDate}
                      onChange={(e) => setFormData({ ...formData, renewalDate: e.target.value })}
                      className="mt-1"
                    />
                  </div>
                  <div>
                    <Label htmlFor="loginEmail">Login Email</Label>
                    <Input
                      id="loginEmail"
                      type="email"
                      value={formData.loginEmail}
                      onChange={(e) => setFormData({ ...formData, loginEmail: e.target.value })}
                      placeholder="email@example.com"
                      className="mt-1"
                    />
                  </div>
                </div>

                <div>
                  <Label htmlFor="continueOrCancel">Continue or Cancel?</Label>
                  <Select value={formData.continueOrCancel} onValueChange={(value) => setFormData({ ...formData, continueOrCancel: value })}>
                    <SelectTrigger className="mt-1">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="Continue">Continue</SelectItem>
                      <SelectItem value="Cancel">Cancel</SelectItem>
                      <SelectItem value="Undecided">Undecided</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div>
                  <Label htmlFor="notes">Notes</Label>
                  <Textarea
                    id="notes"
                    value={formData.notes}
                    onChange={(e) => setFormData({ ...formData, notes: e.target.value })}
                    placeholder="Add any notes..."
                    className="mt-1"
                  />
                </div>

                <Button onClick={handleSave} className="w-full">
                  {editingId ? "Update Subscription" : "Add Subscription"}
                </Button>
              </div>
            </DialogContent>
          </Dialog>
        </div>
      </div>

      {/* Subscriptions List */}
      {subscriptions.length === 0 ? (
        <Card className="card-premium p-12 text-center">
          <p className="text-muted-foreground mb-4">No subscriptions yet. Add your first tool to get started!</p>
          <Button onClick={handleSeedData}>Seed Sample Data</Button>
        </Card>
      ) : (
        <div className="space-y-4">
          {subscriptions.map((sub) => (
            <Card key={sub.id} className="card-premium p-6">
              <div className="flex items-start justify-between mb-4">
                <div className="flex-1">
                  <div className="flex items-center gap-3 mb-2">
                    <h3 className="text-lg font-bold text-foreground">{sub.toolName}</h3>
                    <StatusBadge status={sub.status as any} />
                  </div>
                  <p className="text-sm text-muted-foreground">{sub.category}</p>
                </div>
                <div className="flex gap-2">
                  <Button
                    size="sm"
                    variant="outline"
                    onClick={() => handleOpenDialog(sub)}
                  >
                    <Edit2 className="w-4 h-4" />
                  </Button>
                  <Button
                    size="sm"
                    variant="outline"
                    onClick={() => handleDelete(sub.id)}
                  >
                    <Trash2 className="w-4 h-4" />
                  </Button>
                </div>
              </div>

              <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-sm">
                {sub.monthlyCost && (
                  <div>
                    <p className="text-muted-foreground">Monthly Cost</p>
                    <p className="font-semibold text-foreground">${sub.monthlyCost}</p>
                  </div>
                )}
                {sub.trialEndDate && (
                  <div>
                    <p className="text-muted-foreground">Trial Ends</p>
                    <p className="font-semibold text-foreground">{new Date(sub.trialEndDate).toLocaleDateString()}</p>
                  </div>
                )}
                {sub.renewalDate && (
                  <div>
                    <p className="text-muted-foreground">Renewal Date</p>
                    <p className="font-semibold text-foreground">{new Date(sub.renewalDate).toLocaleDateString()}</p>
                  </div>
                )}
                {sub.loginEmail && (
                  <div>
                    <p className="text-muted-foreground">Login Email</p>
                    <p className="font-semibold text-foreground text-xs truncate">{sub.loginEmail}</p>
                  </div>
                )}
              </div>

              {sub.notes && (
                <div className="mt-4 pt-4 border-t border-border">
                  <p className="text-sm text-muted-foreground mb-1">Notes</p>
                  <p className="text-sm text-foreground">{sub.notes}</p>
                </div>
              )}
            </Card>
          ))}
        </div>
      )}
    </div>
  );
}
