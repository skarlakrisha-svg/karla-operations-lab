import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Award, Download, Share2, ArrowLeft } from "lucide-react";
import { useState } from "react";
import { useLocation } from "wouter";

interface Certificate {
  id: number;
  phaseId: number;
  phaseName: string;
  completionDate: string;
  certificateId: string;
  downloadUrl?: string;
}

const SAMPLE_CERTIFICATES: Certificate[] = [
  {
    id: 1,
    phaseId: 1,
    phaseName: "Phase 1: Foundation",
    completionDate: "2026-05-20",
    certificateId: "CERT-FOUND-001",
    downloadUrl: "#",
  },
];

export default function Certificates() {
  const [, navigate] = useLocation();
  const [selectedCert, setSelectedCert] = useState<Certificate | null>(null);
  const certificates = SAMPLE_CERTIFICATES;

  const handleDownload = (cert: Certificate) => {
    // In production, this would generate and download a PDF
    console.log("Downloading certificate:", cert.certificateId);
  };

  const handleShare = (cert: Certificate) => {
    const shareText = `I just completed ${cert.phaseName} on KS Motion OS! 🎓`;
    if (navigator.share) {
      navigator.share({
        title: "KS Motion OS Certificate",
        text: shareText,
      });
    } else {
      // Fallback: copy to clipboard
      navigator.clipboard.writeText(shareText);
    }
  };

  if (selectedCert) {
    return (
      <div className="p-4 lg:p-8 space-y-6">
        {/* Back Button */}
        <button
          onClick={() => setSelectedCert(null)}
          className="flex items-center gap-2 text-accent hover:text-accent/80 transition-colors"
        >
          <ArrowLeft className="w-4 h-4" />
          Back to Certificates
        </button>

        {/* Certificate Preview */}
        <Card className="card-premium p-8 bg-gradient-to-br from-accent/10 to-accent/5 border-accent/30">
          <div className="text-center space-y-6">
            {/* Certificate Header */}
            <div className="space-y-2">
              <Award className="w-16 h-16 mx-auto text-accent" />
              <h1 className="text-3xl font-bold text-foreground">Certificate of Completion</h1>
              <p className="text-muted-foreground">KS Motion OS Learning Platform</p>
            </div>

            {/* Certificate Content */}
            <div className="space-y-4 py-8 border-y border-accent/20">
              <p className="text-lg text-foreground">This certifies that</p>
              <p className="text-2xl font-bold text-accent">You</p>
              <p className="text-lg text-foreground">
                have successfully completed
              </p>
              <p className="text-2xl font-bold text-foreground">{selectedCert.phaseName}</p>
              <p className="text-sm text-muted-foreground">
                Completed on {new Date(selectedCert.completionDate).toLocaleDateString()}
              </p>
            </div>

            {/* Certificate ID */}
            <div className="space-y-1">
              <p className="text-xs text-muted-foreground">Certificate ID</p>
              <p className="font-mono text-sm text-foreground">{selectedCert.certificateId}</p>
            </div>

            {/* Actions */}
            <div className="flex gap-3 justify-center pt-4">
              <Button
                variant="default"
                size="sm"
                onClick={() => handleDownload(selectedCert)}
                className="gap-2"
              >
                <Download className="w-4 h-4" />
                Download PDF
              </Button>
              <Button
                variant="outline"
                size="sm"
                onClick={() => handleShare(selectedCert)}
                className="gap-2"
              >
                <Share2 className="w-4 h-4" />
                Share
              </Button>
            </div>
          </div>
        </Card>
      </div>
    );
  }

  return (
    <div className="p-4 lg:p-8 space-y-6">
      {/* Header */}
      <div>
        <h1 className="text-3xl font-bold text-foreground">Your Certificates</h1>
        <p className="text-muted-foreground mt-1">
          Celebrate your learning achievements. Earn certificates by completing phases.
        </p>
      </div>

      {/* Certificates Grid */}
      {certificates.length > 0 ? (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {certificates.map((cert) => (
            <Card
              key={cert.id}
              className="card-premium p-6 cursor-pointer hover:border-accent/50 transition-all group"
              onClick={() => setSelectedCert(cert)}
            >
              <div className="space-y-4">
                {/* Icon */}
                <div className="flex items-center justify-between">
                  <Award className="w-8 h-8 text-accent" />
                  <Badge className="bg-accent/10 text-accent border-accent/30">
                    Earned
                  </Badge>
                </div>

                {/* Content */}
                <div className="space-y-2">
                  <h3 className="font-semibold text-foreground group-hover:text-accent transition-colors">
                    {cert.phaseName}
                  </h3>
                  <p className="text-sm text-muted-foreground">
                    Completed on {new Date(cert.completionDate).toLocaleDateString()}
                  </p>
                </div>

                {/* Certificate ID */}
                <div className="pt-2 border-t border-border">
                  <p className="text-xs text-muted-foreground font-mono">{cert.certificateId}</p>
                </div>

                {/* Actions */}
                <div className="flex gap-2 pt-2">
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={(e) => {
                      e.stopPropagation();
                      handleDownload(cert);
                    }}
                    className="flex-1 gap-2"
                  >
                    <Download className="w-3 h-3" />
                    Download
                  </Button>
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={(e) => {
                      e.stopPropagation();
                      handleShare(cert);
                    }}
                    className="flex-1 gap-2"
                  >
                    <Share2 className="w-3 h-3" />
                    Share
                  </Button>
                </div>
              </div>
            </Card>
          ))}
        </div>
      ) : (
        <Card className="card-premium p-12 text-center">
          <Award className="w-12 h-12 text-muted-foreground/50 mx-auto mb-4" />
          <h3 className="text-lg font-semibold text-foreground mb-2">No Certificates Yet</h3>
          <p className="text-muted-foreground mb-6">
            Complete phases to earn certificates and showcase your learning achievements.
          </p>
          <Button onClick={() => navigate("/learning-roadmap")}>
            Start Learning
          </Button>
        </Card>
      )}

      {/* How It Works */}
      <Card className="card-premium p-6">
        <h2 className="text-lg font-bold text-foreground mb-4">How to Earn Certificates</h2>
        <div className="space-y-3">
          <div className="flex gap-3">
            <div className="flex-shrink-0 w-6 h-6 rounded-full bg-accent/20 flex items-center justify-center text-accent text-sm font-bold">
              1
            </div>
            <div>
              <p className="font-semibold text-foreground">Complete a Phase</p>
              <p className="text-sm text-muted-foreground">Reach 100% completion in any learning phase</p>
            </div>
          </div>
          <div className="flex gap-3">
            <div className="flex-shrink-0 w-6 h-6 rounded-full bg-accent/20 flex items-center justify-center text-accent text-sm font-bold">
              2
            </div>
            <div>
              <p className="font-semibold text-foreground">Pass the Quiz (Optional)</p>
              <p className="text-sm text-muted-foreground">Take the phase quiz to unlock an enhanced certificate</p>
            </div>
          </div>
          <div className="flex gap-3">
            <div className="flex-shrink-0 w-6 h-6 rounded-full bg-accent/20 flex items-center justify-center text-accent text-sm font-bold">
              3
            </div>
            <div>
              <p className="font-semibold text-foreground">Download & Share</p>
              <p className="text-sm text-muted-foreground">Download your certificate and share your achievement</p>
            </div>
          </div>
        </div>
      </Card>
    </div>
  );
}
