import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Plus, Trash2, Edit2, Clock, Flame } from "lucide-react";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useState } from "react";
import { toast } from "sonner";

interface StudySession {
  id: string;
  day: string;
  time: string;
  duration: number;
  subject: string;
  status: "Scheduled" | "In Progress" | "Completed" | "Skipped";
  notes?: string;
}

interface MonthlyPriority {
  month: string;
  focus: string;
  goals: string[];
}

const weekdayEveningSessions: StudySession[] = [
  {
    id: "1",
    day: "Monday",
    time: "6:00 PM",
    duration: 90,
    subject: "ChatGPT Fundamentals",
    status: "Scheduled",
    notes: "Focus on prompt engineering techniques",
  },
  {
    id: "2",
    day: "Tuesday",
    time: "6:00 PM",
    duration: 90,
    subject: "Manus Fundamentals",
    status: "Scheduled",
    notes: "Learn tRPC and database design",
  },
  {
    id: "3",
    day: "Wednesday",
    time: "6:00 PM",
    duration: 90,
    subject: "Lovable UI/UX",
    status: "Scheduled",
    notes: "Design systems and components",
  },
  {
    id: "4",
    day: "Thursday",
    time: "6:00 PM",
    duration: 90,
    subject: "SaaS Architecture",
    status: "Scheduled",
    notes: "Business models and scaling",
  },
  {
    id: "5",
    day: "Friday",
    time: "6:00 PM",
    duration: 60,
    subject: "Weekly Review",
    status: "Scheduled",
    notes: "Review what you learned this week",
  },
];

const weekendDeepWorkSessions: StudySession[] = [
  {
    id: "6",
    day: "Saturday",
    time: "9:00 AM",
    duration: 180,
    subject: "Deep Work: Project Building",
    status: "Scheduled",
    notes: "Build a project using this week's learnings",
  },
  {
    id: "7",
    day: "Saturday",
    time: "2:00 PM",
    duration: 120,
    subject: "Deep Work: Experimentation",
    status: "Scheduled",
    notes: "Experiment with new tools and techniques",
  },
  {
    id: "8",
    day: "Sunday",
    time: "10:00 AM",
    duration: 120,
    subject: "Planning & Documentation",
    status: "Scheduled",
    notes: "Plan next week and document learnings",
  },
];

const monthlyPriorities: MonthlyPriority[] = [
  {
    month: "May 2026",
    focus: "Foundation Phase",
    goals: [
      "Master ChatGPT prompt engineering",
      "Complete Manus fundamentals course",
      "Build first internal app with Lovable",
      "Understand SaaS business models",
    ],
  },
  {
    month: "June 2026",
    focus: "Backend & Databases",
    goals: [
      "Learn Supabase and PostgreSQL",
      "Understand database design patterns",
      "Implement authentication systems",
      "Build a backend API",
    ],
  },
  {
    month: "July 2026",
    focus: "Automation Fundamentals",
    goals: [
      "Master Zapier basics",
      "Learn Make workflow automation",
      "Build first automation workflow",
      "Understand CRM automations",
    ],
  },
];

const burnoutPreventionTips = [
  {
    title: "Take Breaks",
    description: "Study for 90 minutes, then take a 15-minute break. Repeat 4 times, then take a longer break.",
  },
  {
    title: "Mix Topics",
    description: "Rotate between different subjects to keep your brain engaged and prevent fatigue.",
  },
  {
    title: "Practice, Don't Just Watch",
    description: "Build projects and experiment with tools. Hands-on learning prevents burnout.",
  },
  {
    title: "Track Progress",
    description: "Celebrate small wins. Mark completed sessions and see your progress grow.",
  },
  {
    title: "Adjust as Needed",
    description: "If a schedule isn't working, adjust it. This is YOUR learning plan.",
  },
  {
    title: "Weekend Rest",
    description: "Sundays after 2 PM are for rest. No studying. Recharge for the week ahead.",
  },
];

const statusColors: Record<string, string> = {
  "Scheduled": "bg-muted text-muted-foreground",
  "In Progress": "bg-accent/10 text-accent",
  "Completed": "bg-green-500/10 text-green-600 dark:text-green-400",
  "Skipped": "bg-destructive/10 text-destructive",
};

function SessionCard({ session, onEdit, onDelete }: { session: StudySession; onEdit: (s: StudySession) => void; onDelete: (id: string) => void }) {
  return (
    <Card className="card-premium p-4">
      <div className="flex items-start justify-between mb-3">
        <div className="flex-1">
          <h3 className="font-bold text-foreground">{session.subject}</h3>
          <div className="flex items-center gap-2 mt-2 text-sm text-muted-foreground">
            <Clock className="w-4 h-4" />
            <span>{session.time} • {session.duration} min</span>
          </div>
        </div>
        <div className="flex gap-1">
          <Button size="sm" variant="outline" onClick={() => onEdit(session)}>
            <Edit2 className="w-4 h-4" />
          </Button>
          <Button size="sm" variant="outline" onClick={() => onDelete(session.id)}>
            <Trash2 className="w-4 h-4" />
          </Button>
        </div>
      </div>

      <div className="flex items-center justify-between">
        <Badge className={`status-badge ${statusColors[session.status]}`}>
          {session.status}
        </Badge>
        {session.notes && (
          <p className="text-xs text-muted-foreground">{session.notes}</p>
        )}
      </div>
    </Card>
  );
}

export default function Planner() {
  const [weekdaySessions, setWeekdaySessions] = useState(weekdayEveningSessions);
  const [weekendSessions, setWeekendSessions] = useState(weekendDeepWorkSessions);
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [editingSession, setEditingSession] = useState<StudySession | null>(null);
  const [sessionType, setSessionType] = useState<"weekday" | "weekend">("weekday");

  const handleEdit = (session: StudySession, type: "weekday" | "weekend") => {
    setEditingSession(session);
    setSessionType(type);
    setIsDialogOpen(true);
  };

  const handleDelete = (id: string, type: "weekday" | "weekend") => {
    if (confirm("Are you sure you want to delete this session?")) {
      if (type === "weekday") {
        setWeekdaySessions(weekdaySessions.filter(s => s.id !== id));
      } else {
        setWeekendSessions(weekendSessions.filter(s => s.id !== id));
      }
      toast.success("Session deleted");
    }
  };

  const handleAddNew = (type: "weekday" | "weekend") => {
    setEditingSession(null);
    setSessionType(type);
    setIsDialogOpen(true);
  };

  const totalHours = [...weekdaySessions, ...weekendSessions].reduce((sum, s) => sum + s.duration, 0) / 60;
  const completedSessions = [...weekdaySessions, ...weekendSessions].filter(s => s.status === "Completed").length;

  return (
    <div className="p-4 lg:p-8 space-y-8">
      {/* Header */}
      <div>
        <h1 className="text-3xl font-bold text-foreground">Study Planner</h1>
        <p className="text-muted-foreground mt-1">
          Your realistic study schedule for Mon–Fri work (8 AM–5 PM EST) with evening study blocks, weekend deep work sessions, and monthly learning priorities.
        </p>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <Card className="card-premium p-6">
          <p className="text-sm text-muted-foreground font-medium">Weekly Study Time</p>
          <p className="text-3xl font-bold text-accent mt-2">{totalHours.toFixed(1)}h</p>
          <p className="text-xs text-muted-foreground mt-1">Realistic and sustainable</p>
        </Card>
        <Card className="card-premium p-6">
          <p className="text-sm text-muted-foreground font-medium">Sessions Completed</p>
          <p className="text-3xl font-bold text-green-500 mt-2">{completedSessions}</p>
          <p className="text-xs text-muted-foreground mt-1">Keep up the momentum!</p>
        </Card>
        <Card className="card-premium p-6">
          <p className="text-sm text-muted-foreground font-medium">Current Phase</p>
          <p className="text-3xl font-bold text-accent mt-2">Phase 1</p>
          <p className="text-xs text-muted-foreground mt-1">Foundation (5 weeks)</p>
        </Card>
      </div>

      {/* Study Schedule */}
      <Tabs defaultValue="weekday" className="w-full">
        <TabsList className="grid w-full grid-cols-2">
          <TabsTrigger value="weekday">Weekday Evening (Mon–Fri)</TabsTrigger>
          <TabsTrigger value="weekend">Weekend Deep Work</TabsTrigger>
        </TabsList>

        {/* Weekday Sessions */}
        <TabsContent value="weekday" className="space-y-4 mt-6">
          <div className="flex items-center justify-between mb-4">
            <div>
              <h2 className="text-xl font-bold text-foreground">Evening Study Blocks</h2>
              <p className="text-sm text-muted-foreground">6:00 PM – 7:30 PM (90 min each)</p>
            </div>
            <Dialog open={isDialogOpen && sessionType === "weekday"} onOpenChange={setIsDialogOpen}>
              <DialogTrigger asChild>
                <Button onClick={() => handleAddNew("weekday")}>
                  <Plus className="w-4 h-4 mr-2" />
                  Add Session
                </Button>
              </DialogTrigger>
              <DialogContent className="max-w-2xl">
                <DialogHeader>
                  <DialogTitle>Add Study Session</DialogTitle>
                </DialogHeader>
                <div className="space-y-4">
                  <div>
                    <Label>Subject</Label>
                    <Input placeholder="What will you study?" className="mt-1" />
                  </div>
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <Label>Day</Label>
                      <Select defaultValue="Monday">
                        <SelectTrigger className="mt-1">
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="Monday">Monday</SelectItem>
                          <SelectItem value="Tuesday">Tuesday</SelectItem>
                          <SelectItem value="Wednesday">Wednesday</SelectItem>
                          <SelectItem value="Thursday">Thursday</SelectItem>
                          <SelectItem value="Friday">Friday</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                    <div>
                      <Label>Duration (minutes)</Label>
                      <Input type="number" placeholder="90" className="mt-1" />
                    </div>
                  </div>
                  <div>
                    <Label>Notes</Label>
                    <Textarea placeholder="What will you focus on?" className="mt-1" />
                  </div>
                  <Button className="w-full">Save Session</Button>
                </div>
              </DialogContent>
            </Dialog>
          </div>

          <div className="space-y-3">
            {weekdaySessions.map((session) => (
              <SessionCard
                key={session.id}
                session={session}
                onEdit={(s) => handleEdit(s, "weekday")}
                onDelete={(id) => handleDelete(id, "weekday")}
              />
            ))}
          </div>

          <Card className="card-premium p-4 bg-accent/5 border-accent/20">
            <p className="text-sm text-foreground">
              <strong>💡 Tip:</strong> These 90-minute evening blocks are designed to fit into your work schedule. Focus on one topic per evening to build deep knowledge.
            </p>
          </Card>
        </TabsContent>

        {/* Weekend Sessions */}
        <TabsContent value="weekend" className="space-y-4 mt-6">
          <div className="flex items-center justify-between mb-4">
            <div>
              <h2 className="text-xl font-bold text-foreground">Weekend Deep Work</h2>
              <p className="text-sm text-muted-foreground">Saturday & Sunday morning sessions</p>
            </div>
            <Dialog open={isDialogOpen && sessionType === "weekend"} onOpenChange={setIsDialogOpen}>
              <DialogTrigger asChild>
                <Button onClick={() => handleAddNew("weekend")}>
                  <Plus className="w-4 h-4 mr-2" />
                  Add Session
                </Button>
              </DialogTrigger>
              <DialogContent className="max-w-2xl">
                <DialogHeader>
                  <DialogTitle>Add Weekend Session</DialogTitle>
                </DialogHeader>
                <div className="space-y-4">
                  <div>
                    <Label>Subject</Label>
                    <Input placeholder="What will you build/explore?" className="mt-1" />
                  </div>
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <Label>Day</Label>
                      <Select defaultValue="Saturday">
                        <SelectTrigger className="mt-1">
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="Saturday">Saturday</SelectItem>
                          <SelectItem value="Sunday">Sunday</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                    <div>
                      <Label>Duration (minutes)</Label>
                      <Input type="number" placeholder="180" className="mt-1" />
                    </div>
                  </div>
                  <div>
                    <Label>Notes</Label>
                    <Textarea placeholder="Project ideas or focus areas" className="mt-1" />
                  </div>
                  <Button className="w-full">Save Session</Button>
                </div>
              </DialogContent>
            </Dialog>
          </div>

          <div className="space-y-3">
            {weekendSessions.map((session) => (
              <SessionCard
                key={session.id}
                session={session}
                onEdit={(s) => handleEdit(s, "weekend")}
                onDelete={(id) => handleDelete(id, "weekend")}
              />
            ))}
          </div>

          <Card className="card-premium p-4 bg-accent/5 border-accent/20">
            <p className="text-sm text-foreground">
              <strong>💡 Tip:</strong> Use weekends for hands-on deep work. Build projects, experiment with tools, and apply what you learned during the week.
            </p>
          </Card>
        </TabsContent>
      </Tabs>

      {/* Monthly Learning Priorities */}
      <div>
        <h2 className="text-2xl font-bold text-foreground mb-4">Monthly Learning Priorities</h2>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          {monthlyPriorities.map((priority) => (
            <Card key={priority.month} className="card-premium p-6">
              <h3 className="font-bold text-foreground text-lg mb-2">{priority.month}</h3>
              <p className="text-sm text-accent font-semibold mb-3">{priority.focus}</p>
              <ul className="space-y-2">
                {priority.goals.map((goal, idx) => (
                  <li key={idx} className="flex items-start gap-2 text-sm text-foreground">
                    <span className="text-accent font-bold">✓</span>
                    <span>{goal}</span>
                  </li>
                ))}
              </ul>
            </Card>
          ))}
        </div>
      </div>

      {/* Burnout Prevention */}
      <div>
        <div className="flex items-center gap-2 mb-4">
          <Flame className="w-6 h-6 text-orange-500" />
          <h2 className="text-2xl font-bold text-foreground">Burnout Prevention</h2>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {burnoutPreventionTips.map((tip, idx) => (
            <Card key={idx} className="card-premium p-5">
              <h3 className="font-bold text-foreground mb-2">{tip.title}</h3>
              <p className="text-sm text-muted-foreground">{tip.description}</p>
            </Card>
          ))}
        </div>
      </div>

      {/* Schedule Summary */}
      <Card className="card-premium p-6 bg-accent/5 border-accent/20">
        <h3 className="text-lg font-bold text-foreground mb-4">Your Study Schedule at a Glance</h3>
        <div className="space-y-3 text-sm text-foreground">
          <p>
            <strong>Weekdays (Mon–Fri):</strong> 6:00 PM – 7:30 PM (90 min) for focused evening study blocks. Perfect for learning while working 8 AM–5 PM.
          </p>
          <p>
            <strong>Saturdays:</strong> 9:00 AM – 2:00 PM (300 min) for deep work projects and experimentation.
          </p>
          <p>
            <strong>Sundays:</strong> 10:00 AM – 12:00 PM (120 min) for planning and documentation. Rest after 2 PM.
          </p>
          <p>
            <strong>Total Weekly Commitment:</strong> ~{totalHours.toFixed(1)} hours (realistic and sustainable)
          </p>
        </div>
      </Card>
    </div>
  );
}
