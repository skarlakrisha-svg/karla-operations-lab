import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { BookOpen, Zap, Map, MessageSquare, Calendar, Lightbulb, Rocket } from "lucide-react";
import { Progress } from "@/components/ui/progress";

const quickLinks = [
  { icon: BookOpen, label: "Learning Roadmap", path: "/learning-roadmap", color: "text-blue-500" },
  { icon: Zap, label: "Tool Ecosystem", path: "/tools", color: "text-yellow-500" },
  { icon: Map, label: "SaaS Roadmap", path: "/roadmap", color: "text-pink-500" },
  { icon: MessageSquare, label: "Learning Vault", path: "/vault", color: "text-purple-500" },
  { icon: Calendar, label: "Study Planner", path: "/planner", color: "text-orange-500" },
];

export default function Dashboard() {
  return (
    <div className="p-4 lg:p-8 space-y-6 max-w-7xl mx-auto">
      {/* Header */}
      <div>
        <h1 className="text-2xl lg:text-4xl font-bold text-foreground">Welcome to KS Motion OS</h1>
        <p className="text-muted-foreground mt-2 text-sm lg:text-base">
          Your centralized learning roadmap, SaaS build tracker, automation learning system, and founder knowledge hub.
        </p>
      </div>

      {/* Key Metrics */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3 lg:gap-4">
        {/* Learning Progress */}
        <Card className="card-premium p-4 lg:p-6">
          <div className="flex items-start justify-between mb-3">
            <div>
              <p className="text-xs lg:text-sm text-muted-foreground font-medium">Learning Progress</p>
              <p className="text-2xl lg:text-3xl font-bold text-accent mt-1 lg:mt-2">Phase 1</p>
            </div>
            <BookOpen className="w-6 lg:w-8 h-6 lg:h-8 text-accent/20" />
          </div>
          <p className="text-xs text-muted-foreground">Foundation Phase</p>
        </Card>

        {/* Active Tools */}
        <Card className="card-premium p-4 lg:p-6">
          <div className="flex items-start justify-between mb-3">
            <div>
              <p className="text-xs lg:text-sm text-muted-foreground font-medium">Active Tools</p>
              <p className="text-2xl lg:text-3xl font-bold text-green-500 mt-1 lg:mt-2">7</p>
            </div>
            <Zap className="w-6 lg:w-8 h-6 lg:h-8 text-green-500/20" />
          </div>
          <p className="text-xs text-muted-foreground">Foundation + Backend + Automation</p>
        </Card>

        {/* Roadmap Progress */}
        <Card className="card-premium p-4 lg:p-6">
          <div className="flex items-start justify-between mb-3">
            <div>
              <p className="text-xs lg:text-sm text-muted-foreground font-medium">SaaS Roadmap</p>
              <p className="text-2xl lg:text-3xl font-bold text-accent mt-1 lg:mt-2">8</p>
            </div>
            <Rocket className="w-6 lg:w-8 h-6 lg:h-8 text-accent/20" />
          </div>
          <p className="text-xs text-muted-foreground">MVP Features</p>
        </Card>
      </div>

      {/* Learning Phases Overview */}
      <Card className="card-premium p-4 lg:p-6">
        <h2 className="text-base lg:text-lg font-bold text-foreground mb-4">Your Learning Journey</h2>
        <div className="space-y-4">
          <div>
            <div className="flex items-center justify-between mb-2 gap-2">
              <span className="font-semibold text-foreground text-sm lg:text-base">Phase 1 — Foundation</span>
              <span className="text-xs lg:text-sm text-accent font-bold whitespace-nowrap">Current</span>
            </div>
            <Progress value={40} className="h-2" />
            <p className="text-xs text-muted-foreground mt-2">
              Master ChatGPT, Manus, Lovable, and SaaS fundamentals
            </p>
          </div>
          <div>
            <div className="flex items-center justify-between mb-2 gap-2">
              <span className="font-semibold text-foreground text-sm lg:text-base">Phase 2 — Backend & Databases</span>
              <span className="text-xs lg:text-sm text-muted-foreground whitespace-nowrap">Next</span>
            </div>
            <Progress value={0} className="h-2" />
            <p className="text-xs text-muted-foreground mt-2">
              Learn Supabase, databases, and authentication
            </p>
          </div>
          <div>
            <div className="flex items-center justify-between mb-2 gap-2">
              <span className="font-semibold text-foreground text-sm lg:text-base">Phase 3 — Automation</span>
              <span className="text-xs lg:text-sm text-muted-foreground whitespace-nowrap">Later</span>
            </div>
            <Progress value={0} className="h-2" />
            <p className="text-xs text-muted-foreground mt-2">
              Master Zapier, Make, and workflow automation
            </p>
          </div>
        </div>
      </Card>

      {/* Quick Access */}
      <div>
        <h2 className="text-base lg:text-lg font-bold text-foreground mb-4">Quick Access</h2>
        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-5 gap-2 lg:gap-4">
          {quickLinks.map((link) => {
            const Icon = link.icon;
            return (
              <a
                key={link.label}
                href={link.path}
                className="card-premium p-3 lg:p-6 flex flex-col items-center justify-center text-center hover:border-accent/50 transition-all duration-200 group"
              >
                <Icon className={`w-6 lg:w-8 h-6 lg:h-8 mb-2 lg:mb-3 ${link.color} group-hover:text-accent transition-colors`} />
                <p className="font-medium text-xs lg:text-sm text-foreground line-clamp-2">{link.label}</p>
              </a>
            );
          })}
        </div>
      </div>

      {/* Getting Started */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4 lg:gap-6">
        {/* Start Learning */}
        <Card className="card-premium p-4 lg:p-6">
          <div className="flex items-start justify-between mb-3 lg:mb-4 gap-3">
            <div>
              <h3 className="text-base lg:text-lg font-bold text-foreground">Start Your Learning Path</h3>
              <p className="text-xs lg:text-sm text-muted-foreground mt-1">
                Follow the structured learning roadmap designed to take you from beginner to advanced SaaS builder.
              </p>
            </div>
            <Lightbulb className="w-5 lg:w-6 h-5 lg:h-6 text-accent/20 flex-shrink-0" />
          </div>
          <a href="/learning-roadmap">
            <Button className="w-full text-sm lg:text-base">View Learning Roadmap</Button>
          </a>
        </Card>

        {/* Explore Tools */}
        <Card className="card-premium p-4 lg:p-6">
          <div className="flex items-start justify-between mb-3 lg:mb-4 gap-3">
            <div>
              <h3 className="text-base lg:text-lg font-bold text-foreground">Explore Your Toolkit</h3>
              <p className="text-xs lg:text-sm text-muted-foreground mt-1">
                Discover all the tools you'll need, organized by learning phase and priority level.
              </p>
            </div>
            <Zap className="w-5 lg:w-6 h-5 lg:h-6 text-accent/20 flex-shrink-0" />
          </div>
          <a href="/tools">
            <Button className="w-full text-sm lg:text-base">View Tool Ecosystem</Button>
          </a>
        </Card>
      </div>

      {/* Tips */}
      <Card className="card-premium p-4 lg:p-6 bg-accent/5 border-accent/20">
        <h3 className="text-base lg:text-lg font-bold text-foreground mb-3">💡 Pro Tips</h3>
        <ul className="space-y-2 text-xs lg:text-sm text-foreground">
          <li>✓ Start with Phase 1 Foundation topics before moving to Phase 2</li>
          <li>✓ Spend 5-10 hours per week on learning for consistent progress</li>
          <li>✓ Use the Learning Vault to save resources and ideas as you discover them</li>
          <li>✓ Track your study sessions in the Study Planner to maintain consistency</li>
          <li>✓ Refer back to the Tool Ecosystem to understand why each tool matters</li>
        </ul>
      </Card>
    </div>
  );
}
