import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { MessageCircle, Heart, Check, TrendingUp, Users, ArrowLeft, Plus } from "lucide-react";
import { useState } from "react";

interface ThreadReply {
  id: number;
  userId: number;
  username: string;
  content: string;
  createdAt: string;
  likes: number;
  isAnswer: boolean;
  isHelpful: boolean;
}

interface DiscussionThread {
  id: number;
  phaseId: number;
  phaseName: string;
  threadTitle: string;
  description: string;
  createdBy: string;
  createdAt: string;
  replyCount: number;
  viewCount: number;
  isResolved: boolean;
  replies: ThreadReply[];
}

const SAMPLE_THREADS: DiscussionThread[] = [
  {
    id: 1,
    phaseId: 1,
    phaseName: "Phase 1: Foundation",
    threadTitle: "Best practices for building dashboards with Lovable",
    description: "What are some best practices you've discovered when building dashboards?",
    createdBy: "Sarah Chen",
    createdAt: "2026-05-20",
    replyCount: 8,
    viewCount: 145,
    isResolved: false,
    replies: [
      {
        id: 1,
        userId: 2,
        username: "Alex Rodriguez",
        content: "I always start with a wireframe to understand the layout before coding. It saves a lot of time!",
        createdAt: "2026-05-20",
        likes: 12,
        isAnswer: true,
        isHelpful: true,
      },
      {
        id: 2,
        userId: 3,
        username: "Jordan Kim",
        content: "Using Tailwind CSS components has been a game changer for me. Much faster development.",
        createdAt: "2026-05-21",
        likes: 8,
        isAnswer: false,
        isHelpful: false,
      },
    ],
  },
  {
    id: 2,
    phaseId: 1,
    phaseName: "Phase 1: Foundation",
    threadTitle: "How to structure SaaS projects for scalability",
    description: "Looking for advice on project structure that scales well",
    createdBy: "Michael Park",
    createdAt: "2026-05-19",
    replyCount: 5,
    viewCount: 89,
    isResolved: true,
    replies: [],
  },
];

type CommunityView = "threads" | "thread-detail" | "leaderboard";

export default function Community() {
  const [view, setView] = useState<CommunityView>("threads");
  const [selectedThread, setSelectedThread] = useState<DiscussionThread | null>(null);
  const [newReply, setNewReply] = useState("");
  const [showNewThread, setShowNewThread] = useState(false);

  const threads = SAMPLE_THREADS;

  const handleSelectThread = (thread: DiscussionThread) => {
    setSelectedThread(thread);
    setView("thread-detail");
  };

  const handlePostReply = () => {
    if (newReply.trim()) {
      console.log("Posting reply:", newReply);
      setNewReply("");
    }
  };

  // Threads List View
  if (view === "threads") {
    return (
      <div className="p-4 lg:p-8 space-y-6">
        {/* Header */}
        <div className="flex items-start justify-between">
          <div>
            <h1 className="text-3xl font-bold text-foreground">Learning Community</h1>
            <p className="text-muted-foreground mt-1">
              Connect with other learners, share resources, and get help from the community.
            </p>
          </div>
          <Button onClick={() => setShowNewThread(true)} className="gap-2">
            <Plus className="w-4 h-4" />
            New Thread
          </Button>
        </div>

        {/* Filter Tabs */}
        <div className="flex gap-2 overflow-x-auto pb-2">
          <Button variant="outline" className="whitespace-nowrap">
            All Threads
          </Button>
          <Button variant="ghost" className="whitespace-nowrap">
            Unanswered
          </Button>
          <Button variant="ghost" className="whitespace-nowrap">
            My Threads
          </Button>
          <Button
            variant="ghost"
            onClick={() => setView("leaderboard")}
            className="whitespace-nowrap gap-2"
          >
            <TrendingUp className="w-4 h-4" />
            Leaderboard
          </Button>
        </div>

        {/* Threads List */}
        <div className="space-y-3">
          {threads.map((thread) => (
            <Card
              key={thread.id}
              className="card-premium p-6 cursor-pointer hover:border-accent/50 transition-all"
              onClick={() => handleSelectThread(thread)}
            >
              <div className="flex items-start justify-between gap-4">
                <div className="flex-1 space-y-2">
                  {/* Title and Status */}
                  <div className="flex items-start gap-2">
                    <h3 className="font-semibold text-foreground text-lg hover:text-accent transition-colors">
                      {thread.threadTitle}
                    </h3>
                    {thread.isResolved && (
                      <Badge className="bg-accent/10 text-accent border-accent/30 flex-shrink-0">
                        <Check className="w-3 h-3 mr-1" />
                        Resolved
                      </Badge>
                    )}
                  </div>

                  {/* Description */}
                  <p className="text-sm text-muted-foreground">{thread.description}</p>

                  {/* Metadata */}
                  <div className="flex items-center gap-4 text-sm text-muted-foreground pt-2">
                    <span>By {thread.createdBy}</span>
                    <span>{new Date(thread.createdAt).toLocaleDateString()}</span>
                    <Badge variant="outline" className="text-xs">
                      {thread.phaseName}
                    </Badge>
                  </div>
                </div>

                {/* Stats */}
                <div className="flex flex-col gap-3 text-right text-sm">
                  <div className="flex items-center gap-1 justify-end text-muted-foreground">
                    <MessageCircle className="w-4 h-4" />
                    <span>{thread.replyCount}</span>
                  </div>
                  <div className="text-xs text-muted-foreground">
                    {thread.viewCount} views
                  </div>
                </div>
              </div>
            </Card>
          ))}
        </div>

        {/* Empty State */}
        {threads.length === 0 && (
          <Card className="card-premium p-12 text-center">
            <MessageCircle className="w-12 h-12 text-muted-foreground/50 mx-auto mb-4" />
            <h3 className="text-lg font-semibold text-foreground mb-2">No Discussions Yet</h3>
            <p className="text-muted-foreground mb-6">
              Be the first to start a discussion thread!
            </p>
            <Button onClick={() => setShowNewThread(true)}>Start a Thread</Button>
          </Card>
        )}
      </div>
    );
  }

  // Thread Detail View
  if (view === "thread-detail" && selectedThread) {
    return (
      <div className="p-4 lg:p-8 space-y-6 max-w-3xl mx-auto">
        {/* Back Button */}
        <button
          onClick={() => {
            setView("threads");
            setSelectedThread(null);
          }}
          className="flex items-center gap-2 text-accent hover:text-accent/80 transition-colors"
        >
          <ArrowLeft className="w-4 h-4" />
          Back to Discussions
        </button>

        {/* Thread Header */}
        <Card className="card-premium p-6">
          <div className="space-y-4">
            <div className="flex items-start justify-between gap-4">
              <div className="flex-1">
                <h1 className="text-2xl font-bold text-foreground">{selectedThread.threadTitle}</h1>
                <p className="text-muted-foreground mt-2">{selectedThread.description}</p>
              </div>
              {selectedThread.isResolved && (
                <Badge className="bg-accent/10 text-accent border-accent/30 flex-shrink-0">
                  <Check className="w-3 h-3 mr-1" />
                  Resolved
                </Badge>
              )}
            </div>

            {/* Thread Meta */}
            <div className="flex items-center gap-4 text-sm text-muted-foreground pt-4 border-t border-border">
              <span>Started by {selectedThread.createdBy}</span>
              <span>{new Date(selectedThread.createdAt).toLocaleDateString()}</span>
              <Badge variant="outline">{selectedThread.phaseName}</Badge>
              <span className="ml-auto">{selectedThread.replyCount} replies</span>
            </div>
          </div>
        </Card>

        {/* Replies */}
        <div className="space-y-4">
          <h2 className="font-semibold text-foreground">Replies ({selectedThread.replyCount})</h2>
          {selectedThread.replies.map((reply) => (
            <Card key={reply.id} className="card-premium p-6">
              <div className="space-y-4">
                {/* Reply Header */}
                <div className="flex items-start justify-between">
                  <div>
                    <p className="font-semibold text-foreground">{reply.username}</p>
                    <p className="text-sm text-muted-foreground">
                      {new Date(reply.createdAt).toLocaleDateString()}
                    </p>
                  </div>
                  {reply.isAnswer && (
                    <Badge className="bg-accent/10 text-accent border-accent/30">
                      <Check className="w-3 h-3 mr-1" />
                      Answer
                    </Badge>
                  )}
                </div>

                {/* Reply Content */}
                <p className="text-foreground">{reply.content}</p>

                {/* Reply Actions */}
                <div className="flex items-center gap-4 pt-2 border-t border-border">
                  <Button variant="ghost" size="sm" className="gap-2">
                    <Heart className="w-4 h-4" />
                    {reply.likes}
                  </Button>
                  {reply.isHelpful && (
                    <Badge variant="outline" className="text-xs">
                      Helpful
                    </Badge>
                  )}
                </div>
              </div>
            </Card>
          ))}
        </div>

        {/* Reply Composer */}
        <Card className="card-premium p-6">
          <h3 className="font-semibold text-foreground mb-4">Add Your Reply</h3>
          <div className="space-y-4">
            <Textarea
              placeholder="Share your thoughts, answer, or ask a follow-up question..."
              value={newReply}
              onChange={(e) => setNewReply(e.target.value)}
              className="min-h-32"
            />
            <div className="flex gap-3 justify-end">
              <Button variant="outline">Cancel</Button>
              <Button onClick={handlePostReply} disabled={!newReply.trim()}>
                Post Reply
              </Button>
            </div>
          </div>
        </Card>
      </div>
    );
  }

  // Leaderboard View
  if (view === "leaderboard") {
    const leaderboardData = [
      { rank: 1, username: "Sarah Chen", points: 2450, badges: 5, threadsCreated: 12 },
      { rank: 2, username: "Alex Rodriguez", points: 2180, badges: 4, threadsCreated: 8 },
      { rank: 3, username: "Jordan Kim", points: 1920, badges: 3, threadsCreated: 6 },
      { rank: 4, username: "Michael Park", points: 1650, badges: 2, threadsCreated: 4 },
      { rank: 5, username: "Emma Wilson", points: 1420, badges: 2, threadsCreated: 3 },
    ];

    return (
      <div className="p-4 lg:p-8 space-y-6">
        {/* Back Button */}
        <button
          onClick={() => setView("threads")}
          className="flex items-center gap-2 text-accent hover:text-accent/80 transition-colors"
        >
          <ArrowLeft className="w-4 h-4" />
          Back to Discussions
        </button>

        {/* Header */}
        <div>
          <h1 className="text-3xl font-bold text-foreground">Community Leaderboard</h1>
          <p className="text-muted-foreground mt-1">
            Top contributors and most helpful community members
          </p>
        </div>

        {/* Leaderboard Table */}
        <Card className="card-premium overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead>
                <tr className="border-b border-border">
                  <th className="px-6 py-4 text-left font-semibold text-foreground">Rank</th>
                  <th className="px-6 py-4 text-left font-semibold text-foreground">User</th>
                  <th className="px-6 py-4 text-center font-semibold text-foreground">Points</th>
                  <th className="px-6 py-4 text-center font-semibold text-foreground">Badges</th>
                  <th className="px-6 py-4 text-center font-semibold text-foreground">Threads</th>
                </tr>
              </thead>
              <tbody>
                {leaderboardData.map((entry, idx) => (
                  <tr
                    key={idx}
                    className={`border-b border-border hover:bg-muted/50 transition-colors ${
                      idx === 0 ? "bg-accent/5" : ""
                    }`}
                  >
                    <td className="px-6 py-4">
                      <div className="flex items-center gap-2">
                        <div
                          className={`w-8 h-8 rounded-full flex items-center justify-center font-bold text-sm ${
                            idx === 0
                              ? "bg-accent text-background"
                              : idx === 1
                              ? "bg-muted text-foreground"
                              : idx === 2
                              ? "bg-orange-500/20 text-orange-600"
                              : "bg-muted text-foreground"
                          }`}
                        >
                          {entry.rank}
                        </div>
                      </div>
                    </td>
                    <td className="px-6 py-4 font-semibold text-foreground">{entry.username}</td>
                    <td className="px-6 py-4 text-center text-accent font-bold">{entry.points}</td>
                    <td className="px-6 py-4 text-center">
                      <div className="flex items-center justify-center gap-1">
                        <span className="text-lg">⭐</span>
                        <span className="text-foreground">{entry.badges}</span>
                      </div>
                    </td>
                    <td className="px-6 py-4 text-center text-foreground">{entry.threadsCreated}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </Card>

        {/* How to Earn Points */}
        <Card className="card-premium p-6">
          <h2 className="text-lg font-bold text-foreground mb-4">How to Earn Points</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="flex gap-3">
              <div className="flex-shrink-0 w-8 h-8 rounded-full bg-accent/20 flex items-center justify-center text-accent text-sm font-bold">
                +
              </div>
              <div>
                <p className="font-semibold text-foreground">Create Thread</p>
                <p className="text-sm text-muted-foreground">50 points</p>
              </div>
            </div>
            <div className="flex gap-3">
              <div className="flex-shrink-0 w-8 h-8 rounded-full bg-accent/20 flex items-center justify-center text-accent text-sm font-bold">
                +
              </div>
              <div>
                <p className="font-semibold text-foreground">Post Reply</p>
                <p className="text-sm text-muted-foreground">10 points</p>
              </div>
            </div>
            <div className="flex gap-3">
              <div className="flex-shrink-0 w-8 h-8 rounded-full bg-accent/20 flex items-center justify-center text-accent text-sm font-bold">
                +
              </div>
              <div>
                <p className="font-semibold text-foreground">Get Like</p>
                <p className="text-sm text-muted-foreground">5 points</p>
              </div>
            </div>
            <div className="flex gap-3">
              <div className="flex-shrink-0 w-8 h-8 rounded-full bg-accent/20 flex items-center justify-center text-accent text-sm font-bold">
                +
              </div>
              <div>
                <p className="font-semibold text-foreground">Mark as Helpful</p>
                <p className="text-sm text-muted-foreground">25 points</p>
              </div>
            </div>
          </div>
        </Card>
      </div>
    );
  }

  return null;
}
