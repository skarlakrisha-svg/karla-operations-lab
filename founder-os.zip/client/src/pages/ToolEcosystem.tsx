import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { ExternalLink } from "lucide-react";

interface Tool {
  name: string;
  purpose: string;
  whyItMatters: string;
  status: "Active" | "Learning" | "Deferred";
  priority: "Critical" | "High" | "Medium" | "Low";
  learningProgress: number;
  notes?: string;
}

const toolsByCategory: Record<string, Tool[]> = {
  foundation: [
    {
      name: "ChatGPT",
      purpose: "AI-powered content generation, ideation, and problem-solving",
      whyItMatters: "Essential for rapid prototyping, writing, and brainstorming. Accelerates learning and development.",
      status: "Active",
      priority: "Critical",
      learningProgress: 60,
      notes: "Master prompt engineering for maximum effectiveness",
    },
    {
      name: "Manus",
      purpose: "AI-powered app builder and automation platform",
      whyItMatters: "Core platform for building your SaaS apps and automations. Central to your workflow.",
      status: "Active",
      priority: "Critical",
      learningProgress: 40,
      notes: "Learn tRPC, database design, and API integration",
    },
    {
      name: "Lovable",
      purpose: "AI-powered frontend builder for rapid UI development",
      whyItMatters: "Speeds up frontend development and design implementation. Perfect for MVPs.",
      status: "Active",
      priority: "High",
      learningProgress: 50,
      notes: "Focus on design systems and component reusability",
    },
  ],
  backend: [
    {
      name: "Supabase",
      purpose: "Open-source Firebase alternative with PostgreSQL backend",
      whyItMatters: "Provides database, authentication, and real-time capabilities. Essential for SaaS apps.",
      status: "Learning",
      priority: "Critical",
      learningProgress: 30,
      notes: "Master PostgreSQL, row-level security, and real-time subscriptions",
    },
    {
      name: "GitHub",
      purpose: "Version control and collaboration platform",
      whyItMatters: "Essential for code management, collaboration, and deployment workflows.",
      status: "Active",
      priority: "High",
      learningProgress: 70,
      notes: "Learn GitHub Actions for CI/CD automation",
    },
    {
      name: "Vercel",
      purpose: "Frontend deployment and hosting platform",
      whyItMatters: "Simplifies deployment and provides edge functions. Perfect for Next.js apps.",
      status: "Active",
      priority: "High",
      learningProgress: 65,
      notes: "Explore serverless functions and edge middleware",
    },
  ],
  automation: [
    {
      name: "Zapier",
      purpose: "No-code automation and workflow builder",
      whyItMatters: "Connects apps and automates repetitive tasks. Essential for operational efficiency.",
      status: "Learning",
      priority: "High",
      learningProgress: 40,
      notes: "Build multi-step workflows and error handling",
    },
    {
      name: "Make",
      purpose: "Visual workflow automation platform",
      whyItMatters: "More powerful than Zapier for complex automations. Better for advanced workflows.",
      status: "Learning",
      priority: "High",
      learningProgress: 25,
      notes: "Learn advanced routing and data transformation",
    },
  ],
  business: [
    {
      name: "GoHighLevel",
      purpose: "All-in-one CRM and business operations platform",
      whyItMatters: "Manages client relationships, sales pipelines, and automations. Critical for agencies.",
      status: "Learning",
      priority: "Medium",
      learningProgress: 35,
      notes: "Master CRM workflows and client management",
    },
  ],
  deferred: [
    {
      name: "Claude",
      purpose: "Advanced AI model for complex reasoning tasks",
      whyItMatters: "Alternative to ChatGPT with different strengths. Explore after mastering ChatGPT.",
      status: "Deferred",
      priority: "Medium",
      learningProgress: 0,
      notes: "Revisit after Phase 1 completion",
    },
    {
      name: "Cursor",
      purpose: "AI-powered code editor",
      whyItMatters: "Advanced IDE with AI assistance. Explore after mastering basic development.",
      status: "Deferred",
      priority: "Medium",
      learningProgress: 0,
      notes: "Consider after Phase 2 completion",
    },
    {
      name: "n8n",
      purpose: "Self-hosted workflow automation platform",
      whyItMatters: "Advanced alternative to Zapier/Make. Explore after mastering basic automation.",
      status: "Deferred",
      priority: "Low",
      learningProgress: 0,
      notes: "Revisit after Phase 3 completion",
    },
  ],
};

const statusColors: Record<string, string> = {
  Active: "bg-green-500/10 text-green-600 dark:text-green-400 border-green-500/30",
  Learning: "bg-accent/10 text-accent border-accent/30",
  Deferred: "bg-muted text-muted-foreground border-border",
};

const priorityColors: Record<string, string> = {
  Critical: "bg-destructive/10 text-destructive border-destructive/30",
  High: "bg-accent/10 text-accent border-accent/30",
  Medium: "bg-blue-500/10 text-blue-600 dark:text-blue-400 border-blue-500/30",
  Low: "bg-muted text-muted-foreground border-border",
};

function ToolCard({ tool }: { tool: Tool }) {
  return (
    <Card className="card-premium p-6">
      <div className="flex items-start justify-between mb-4">
        <h3 className="text-lg font-bold text-foreground">{tool.name}</h3>
        <div className="flex gap-2">
          <Badge className={`status-badge ${statusColors[tool.status]}`}>
            {tool.status}
          </Badge>
          <Badge className={`status-badge ${priorityColors[tool.priority]}`}>
            {tool.priority}
          </Badge>
        </div>
      </div>

      <div className="space-y-3 mb-4">
        <div>
          <p className="text-xs text-muted-foreground font-semibold mb-1">PURPOSE</p>
          <p className="text-sm text-foreground">{tool.purpose}</p>
        </div>
        <div>
          <p className="text-xs text-muted-foreground font-semibold mb-1">WHY IT MATTERS</p>
          <p className="text-sm text-foreground">{tool.whyItMatters}</p>
        </div>
      </div>

      {/* Progress Bar */}
      <div className="mb-4">
        <div className="flex items-center justify-between mb-2">
          <p className="text-xs text-muted-foreground font-semibold">LEARNING PROGRESS</p>
          <p className="text-xs font-semibold text-foreground">{tool.learningProgress}%</p>
        </div>
        <div className="w-full h-2 bg-muted rounded-full overflow-hidden">
          <div
            className="h-full bg-accent transition-all duration-300"
            style={{ width: `${tool.learningProgress}%` }}
          ></div>
        </div>
      </div>

      {tool.notes && (
        <div className="p-3 rounded-lg bg-muted/50 border border-border">
          <p className="text-xs text-muted-foreground font-semibold mb-1">NOTES</p>
          <p className="text-sm text-foreground">{tool.notes}</p>
        </div>
      )}
    </Card>
  );
}

export default function ToolEcosystem() {
  return (
    <div className="p-4 lg:p-8 space-y-6">
      {/* Header */}
      <div>
        <h1 className="text-3xl font-bold text-foreground">Tool Ecosystem</h1>
        <p className="text-muted-foreground mt-1">
          Your complete toolkit for SaaS development, automation, and business operations. Each tool is categorized by learning phase and priority.
        </p>
      </div>

      {/* Tabs */}
      <Tabs defaultValue="foundation" className="w-full">
        <TabsList className="grid w-full grid-cols-5">
          <TabsTrigger value="foundation">Foundation</TabsTrigger>
          <TabsTrigger value="backend">Backend</TabsTrigger>
          <TabsTrigger value="automation">Automation</TabsTrigger>
          <TabsTrigger value="business">Business</TabsTrigger>
          <TabsTrigger value="deferred">Deferred</TabsTrigger>
        </TabsList>

        {/* Foundation Tools */}
        <TabsContent value="foundation" className="space-y-4 mt-6">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {toolsByCategory.foundation.map((tool) => (
              <ToolCard key={tool.name} tool={tool} />
            ))}
          </div>
        </TabsContent>

        {/* Backend Tools */}
        <TabsContent value="backend" className="space-y-4 mt-6">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {toolsByCategory.backend.map((tool) => (
              <ToolCard key={tool.name} tool={tool} />
            ))}
          </div>
        </TabsContent>

        {/* Automation Tools */}
        <TabsContent value="automation" className="space-y-4 mt-6">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {toolsByCategory.automation.map((tool) => (
              <ToolCard key={tool.name} tool={tool} />
            ))}
          </div>
        </TabsContent>

        {/* Business Tools */}
        <TabsContent value="business" className="space-y-4 mt-6">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {toolsByCategory.business.map((tool) => (
              <ToolCard key={tool.name} tool={tool} />
            ))}
          </div>
        </TabsContent>

        {/* Deferred Tools */}
        <TabsContent value="deferred" className="space-y-4 mt-6">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {toolsByCategory.deferred.map((tool) => (
              <ToolCard key={tool.name} tool={tool} />
            ))}
          </div>
        </TabsContent>
      </Tabs>

      {/* Summary */}
      <Card className="card-premium p-6">
        <h2 className="text-lg font-bold text-foreground mb-4">Your Toolkit Strategy</h2>
        <div className="space-y-3 text-sm text-muted-foreground">
          <p>
            <strong className="text-foreground">Foundation Phase:</strong> Master ChatGPT, Manus, and Lovable first. These are your core tools.
          </p>
          <p>
            <strong className="text-foreground">Backend Phase:</strong> Learn Supabase, GitHub, and Vercel to understand how data and deployment work.
          </p>
          <p>
            <strong className="text-foreground">Automation Phase:</strong> Explore Zapier and Make to build operational workflows.
          </p>
          <p>
            <strong className="text-foreground">Business Phase:</strong> Master GoHighLevel for CRM and client management.
          </p>
          <p>
            <strong className="text-foreground">Advanced Phase:</strong> Explore Claude, Cursor, and n8n for advanced capabilities.
          </p>
        </div>
      </Card>
    </div>
  );
}
