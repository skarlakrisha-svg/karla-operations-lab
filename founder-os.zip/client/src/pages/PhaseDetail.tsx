import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Progress } from "@/components/ui/progress";
import { ArrowLeft, Plus, Trash2, Edit2, BookOpen, Link2, FileText, Clock } from "lucide-react";
import { useState, useEffect } from "react";
import { useRoute, useLocation } from "wouter";
import { toast } from "sonner";
import { trpc } from "@/lib/trpc";
import { Card } from "@/components/ui/card";

const PHASE_DATA = {
  1: {
    title: "Phase 1: Foundation",
    description: "Build core understanding of SaaS, frontend development, and founder operations",
    priority: "Critical",
    estimatedHours: 40,
    topics: ["ChatGPT", "Manus", "Lovable", "SaaS Concepts", "UI/UX", "Dashboard Design", "Founder Workflow", "MVP"],
    goals: ["Understand SaaS business models", "Build your first internal app", "Learn dashboard organization", "Master frontend fundamentals"],
    keyConceptsContent: `## Key Concepts for Phase 1

### 1. SaaS Fundamentals
- Subscription-based business model
- Customer acquisition and retention
- Recurring revenue metrics
- Product-market fit

### 2. Frontend Development with Lovable
- Component-based architecture
- Responsive design principles
- UI/UX best practices
- Accessibility standards

### 3. AI-Powered Development with ChatGPT & Manus
- Prompt engineering techniques
- AI-assisted coding
- Rapid prototyping
- Automation workflows

### 4. Dashboard Design
- Information hierarchy
- User experience patterns
- Data visualization
- Navigation structures`,
    learningOutline: `## Learning Progression

**Week 1-2: SaaS & Business Foundations**
- Day 1-2: SaaS business models and metrics
- Day 3-4: Customer journey mapping
- Day 5: Case studies of successful SaaS products

**Week 3-4: Frontend Fundamentals**
- Day 1-2: Component design patterns
- Day 3-4: Responsive design and mobile-first approach
- Day 5: Accessibility and usability

**Week 5-6: Building Your First App**
- Day 1-2: Project planning and wireframing
- Day 3-4: Development with Lovable
- Day 5: Testing and deployment

**Week 7-8: Dashboard Mastery**
- Day 1-2: Dashboard design principles
- Day 3-4: Data visualization
- Day 5: User feedback and iteration`,
  },
  2: {
    title: "Phase 2: Backend & Databases",
    description: "Master backend development, database design, and API architecture",
    priority: "High",
    estimatedHours: 35,
    topics: ["Supabase", "Databases", "Auth", "Tables", "File Uploads", "APIs"],
    goals: ["Understand backend logic", "Design efficient databases", "Build secure authentication"],
    keyConceptsContent: `## Key Concepts for Phase 2

### 1. Database Design
- Relational database concepts
- Schema design patterns
- Indexing and optimization
- Data integrity

### 2. Authentication & Security
- User authentication flows
- JWT tokens
- Password security
- Authorization patterns

### 3. APIs & Integration
- RESTful API design
- API authentication
- Error handling
- Rate limiting`,
    learningOutline: `## Learning Progression

**Week 1-2: Database Fundamentals**
- Day 1-2: SQL basics and queries
- Day 3-4: Schema design patterns
- Day 5: Performance optimization

**Week 3-4: Authentication**
- Day 1-2: User authentication flows
- Day 3-4: JWT and session management
- Day 5: Security best practices

**Week 5-6: API Development**
- Day 1-2: RESTful API design
- Day 3-4: API authentication
- Day 5: Integration patterns`,
  },
  3: {
    title: "Phase 3: Automation",
    description: "Master automation tools and workflow design",
    priority: "High",
    estimatedHours: 30,
    topics: ["Zapier", "Make", "Workflow Logic", "Triggers/Actions", "Architecture"],
    goals: ["Build complex workflows", "Understand automation architecture", "Learn operational automations"],
    keyConceptsContent: `## Key Concepts for Phase 3

### 1. Workflow Design
- Trigger and action patterns
- Conditional logic
- Error handling
- Workflow optimization

### 2. Integration Patterns
- API connections
- Data mapping
- Webhook handling
- Rate limiting

### 3. Automation Best Practices
- Testing workflows
- Monitoring and logging
- Scalability considerations
- Cost optimization`,
    learningOutline: `## Learning Progression

**Week 1-2: Automation Basics**
- Day 1-2: Trigger and action patterns
- Day 3-4: Building simple workflows
- Day 5: Testing and debugging

**Week 3-4: Advanced Automation**
- Day 1-2: Conditional logic
- Day 3-4: Multi-step workflows
- Day 5: Error handling

**Week 5-6: Production Automation**
- Day 1-2: Monitoring and logging
- Day 3-4: Scaling workflows
- Day 5: Cost optimization`,
  },
  4: {
    title: "Phase 4: Business Operations",
    description: "Learn CRM, sales pipelines, and operational systems",
    priority: "Medium",
    estimatedHours: 28,
    topics: ["GoHighLevel", "CRM", "Sales Pipelines", "Lead Tracking", "Client Onboarding"],
    goals: ["Understand CRM systems", "Build sales pipelines", "Learn client management"],
    keyConceptsContent: `## Key Concepts for Phase 4

### 1. CRM Systems
- Customer data management
- Pipeline stages
- Lead scoring
- Relationship tracking

### 2. Sales Operations
- Sales pipeline design
- Lead qualification
- Conversion optimization
- Revenue tracking

### 3. Client Management
- Onboarding workflows
- Communication systems
- Service delivery
- Retention strategies`,
    learningOutline: `## Learning Progression

**Week 1-2: CRM Fundamentals**
- Day 1-2: CRM concepts and benefits
- Day 3-4: Customer data management
- Day 5: Pipeline setup

**Week 3-4: Sales Operations**
- Day 1-2: Sales pipeline design
- Day 3-4: Lead management
- Day 5: Conversion optimization

**Week 5-6: Client Management**
- Day 1-2: Onboarding workflows
- Day 3-4: Communication systems
- Day 5: Retention strategies`,
  },
  5: {
    title: "Phase 5: Advanced Systems",
    description: "Explore AI integrations, advanced automation, and scalable architecture",
    priority: "Later",
    estimatedHours: 40,
    topics: ["OpenAI API", "AI Integrations", "Cursor", "n8n", "Advanced Backend", "AI Agents"],
    goals: ["Add AI features to apps", "Build advanced SaaS systems", "Create scalable automations"],
    keyConceptsContent: `## Key Concepts for Phase 5

### 1. OpenAI API & LLMs
- GPT models and capabilities
- Prompt engineering
- Fine-tuning and customization
- Cost optimization

### 2. AI Integration Patterns
- Chat interfaces
- Content generation
- Data analysis with AI
- Autonomous agents

### 3. Advanced Automation with n8n
- Complex workflow design
- Custom code execution
- API integrations
- Error handling and monitoring

### 4. Cursor IDE & AI-Assisted Development
- AI code generation
- Debugging with AI
- Rapid prototyping
- Code optimization`,
    learningOutline: `## Learning Progression

**Week 1-2: OpenAI API Fundamentals**
- Day 1-2: API setup and authentication
- Day 3-4: Prompt engineering techniques
- Day 5: Building chat applications

**Week 3-4: AI Integration Patterns**
- Day 1-2: Content generation systems
- Day 3-4: Data analysis with AI
- Day 5: Building AI agents

**Week 5-6: Advanced Automation**
- Day 1-2: n8n platform mastery
- Day 3-4: Complex workflow design
- Day 5: Custom integrations

**Week 7-8: Production Deployment**
- Day 1-2: Scalability and performance
- Day 3-4: Monitoring and logging
- Day 5: Cost optimization and best practices`,
  },
};

interface PhaseResource {
  id: number;
  title: string;
  resourceType: "Video" | "Article" | "Link" | "Document";
  url: string;
  description?: string;
  duration?: number;
}

interface PhaseNotes {
  personalNotes?: string;
  whatILearned?: string;
  keyTakeaways?: string;
  whatToRevisit?: string;
}

export default function PhaseDetail() {
  const [, params] = useRoute("/phase/:id");
  const [, navigate] = useLocation();
  const phaseId = params?.id ? parseInt(params.id) : 1;

  const phaseInfo = PHASE_DATA[phaseId as keyof typeof PHASE_DATA] || PHASE_DATA[1];

  const [resources, setResources] = useState<PhaseResource[]>([]);
  const [notes, setNotes] = useState<PhaseNotes>({});
  const [isAddingResource, setIsAddingResource] = useState(false);
  const [newResource, setNewResource] = useState({
    title: "",
    resourceType: "Video" as const,
    url: "",
    description: "",
    duration: "",
  });
  const [completionPercentage, setCompletionPercentage] = useState(0);
  const [status, setStatus] = useState<"Not Started" | "In Progress" | "Completed">("Not Started");

  useEffect(() => {
    setCompletionPercentage(Math.floor(Math.random() * 60));
    setStatus("In Progress");
  }, [phaseId]);

  const handleAddResource = () => {
    if (newResource.title && newResource.url) {
      const resource: PhaseResource = {
        id: Date.now(),
        title: newResource.title,
        resourceType: newResource.resourceType,
        url: newResource.url,
        description: newResource.description,
        duration: newResource.duration ? parseInt(newResource.duration) : undefined,
      };
      setResources([...resources, resource]);
      setNewResource({ title: "", resourceType: "Video", url: "", description: "", duration: "" });
      setIsAddingResource(false);
      toast.success("Resource added!");
    }
  };

  const handleDeleteResource = (id: number) => {
    setResources(resources.filter((r) => r.id !== id));
    toast.success("Resource deleted!");
  };

  const handleUpdateProgress = (percentage: number) => {
    setCompletionPercentage(percentage);
  };

  const handleUpdateNotes = (field: keyof PhaseNotes, value: string) => {
    setNotes({ ...notes, [field]: value });
  };

  const handleNextPhase = () => {
    if (phaseId < 5) {
      navigate(`/phase/${phaseId + 1}`);
    }
  };

  const handlePrevPhase = () => {
    if (phaseId > 1) {
      navigate(`/phase/${phaseId - 1}`);
    }
  };

  const statusColors = {
    "Not Started": "bg-muted text-muted-foreground",
    "In Progress": "bg-accent/10 text-accent",
    "Completed": "bg-green-500/10 text-green-600 dark:text-green-400",
  };

  return (
    <div className="min-h-screen bg-background pb-8">
      {/* Header with Back Button */}
      <div className="sticky top-14 lg:top-0 z-30 bg-background/95 backdrop-blur border-b border-border">
        <div className="max-w-4xl mx-auto px-4 py-3 lg:py-4 flex items-center justify-between gap-3">
          <div className="flex items-center gap-2 lg:gap-4 min-w-0">
            <Button
              variant="outline"
              size="sm"
              onClick={() => navigate("/learning-roadmap")}
              className="gap-2 flex-shrink-0"
            >
              <ArrowLeft className="w-4 h-4" />
              <span className="hidden sm:inline">Back</span>
            </Button>
            <div className="min-w-0">
              <h1 className="text-lg lg:text-2xl font-bold text-foreground truncate">{phaseInfo.title}</h1>
              <p className="text-xs lg:text-sm text-muted-foreground truncate">{phaseInfo.description}</p>
            </div>
          </div>
          <Badge className={`status-badge ${statusColors[status]} flex-shrink-0`}>{status}</Badge>
        </div>
      </div>

      {/* Main Content */}
      <div className="max-w-4xl mx-auto px-4 py-4 lg:py-8 space-y-4 lg:space-y-8">
        {/* Progress Section */}
        <Card className="card-premium p-4 lg:p-6">
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <h2 className="text-base lg:text-lg font-bold text-foreground">Your Progress</h2>
              <span className="text-xl lg:text-2xl font-bold text-accent">{completionPercentage}%</span>
            </div>
            <Progress value={completionPercentage} className="h-3" />
            <div className="grid grid-cols-3 sm:grid-cols-5 gap-2">
              {[0, 25, 50, 75, 100].map((pct) => (
                <Button
                  key={pct}
                  variant={completionPercentage === pct ? "default" : "outline"}
                  size="sm"
                  onClick={() => handleUpdateProgress(pct)}
                  className="text-xs"
                >
                  {pct}%
                </Button>
              ))}
            </div>
          </div>
        </Card>

        {/* Phase Info Cards */}
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 lg:gap-4">
          <Card className="card-premium p-3 lg:p-4">
            <div className="flex items-start gap-2 lg:gap-3">
              <Clock className="w-4 lg:w-5 h-4 lg:h-5 text-accent mt-1 flex-shrink-0" />
              <div className="min-w-0">
                <p className="text-xs lg:text-sm text-muted-foreground font-medium">Estimated Time</p>
                <p className="text-lg lg:text-xl font-bold text-foreground">{phaseInfo.estimatedHours}h</p>
              </div>
            </div>
          </Card>
          <Card className="card-premium p-3 lg:p-4">
            <div className="flex items-start gap-2 lg:gap-3">
              <BookOpen className="w-4 lg:w-5 h-4 lg:h-5 text-accent mt-1 flex-shrink-0" />
              <div className="min-w-0">
                <p className="text-xs lg:text-sm text-muted-foreground font-medium">Topics</p>
                <p className="text-lg lg:text-xl font-bold text-foreground">{phaseInfo.topics.length}</p>
              </div>
            </div>
          </Card>
          <Card className="card-premium p-3 lg:p-4">
            <div className="flex items-start gap-2 lg:gap-3">
              <Link2 className="w-4 lg:w-5 h-4 lg:h-5 text-accent mt-1 flex-shrink-0" />
              <div className="min-w-0">
                <p className="text-xs lg:text-sm text-muted-foreground font-medium">Resources</p>
                <p className="text-lg lg:text-xl font-bold text-foreground">{resources.length}</p>
              </div>
            </div>
          </Card>
        </div>

        {/* Learning Content */}
        <Card className="card-premium p-4 lg:p-6">
          <h2 className="text-base lg:text-xl font-bold text-foreground mb-4">Key Concepts</h2>
          <div className="prose prose-sm dark:prose-invert max-w-none text-xs lg:text-sm">
            {phaseInfo.keyConceptsContent.split("\n").map((line, i) => (
              <p key={i} className="text-foreground mb-2">
                {line}
              </p>
            ))}
          </div>
        </Card>

        {/* Learning Outline */}
        <Card className="card-premium p-4 lg:p-6">
          <h2 className="text-base lg:text-xl font-bold text-foreground mb-4">Learning Progression</h2>
          <div className="prose prose-sm dark:prose-invert max-w-none text-xs lg:text-sm">
            {phaseInfo.learningOutline.split("\n").map((line, i) => (
              <p key={i} className="text-foreground mb-2">
                {line}
              </p>
            ))}
          </div>
        </Card>

        {/* Resources Section */}
        <Card className="card-premium p-4 lg:p-6">
          <div className="flex items-center justify-between mb-4 gap-2">
            <h2 className="text-base lg:text-lg font-bold text-foreground">Learning Resources</h2>
            <Dialog open={isAddingResource} onOpenChange={setIsAddingResource}>
              <DialogTrigger asChild>
                <Button size="sm" className="gap-2 flex-shrink-0">
                  <Plus className="w-4 h-4" />
                  <span className="hidden sm:inline">Add Resource</span>
                </Button>
              </DialogTrigger>
              <DialogContent className="w-[95vw] max-w-md">
                <DialogHeader>
                  <DialogTitle>Add Learning Resource</DialogTitle>
                </DialogHeader>
                <div className="space-y-4">
                  <div>
                    <Label htmlFor="title">Resource Title</Label>
                    <Input
                      id="title"
                      value={newResource.title}
                      onChange={(e) => setNewResource({ ...newResource, title: e.target.value })}
                      placeholder="e.g., Supabase Auth Tutorial"
                    />
                  </div>
                  <div>
                    <Label htmlFor="type">Resource Type</Label>
                    <Select value={newResource.resourceType} onValueChange={(value: any) => setNewResource({ ...newResource, resourceType: value })}>
                      <SelectTrigger id="type">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="Video">Video</SelectItem>
                        <SelectItem value="Article">Article</SelectItem>
                        <SelectItem value="Link">Link</SelectItem>
                        <SelectItem value="Document">Document</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <div>
                    <Label htmlFor="url">URL</Label>
                    <Input
                      id="url"
                      value={newResource.url}
                      onChange={(e) => setNewResource({ ...newResource, url: e.target.value })}
                      placeholder="https://..."
                    />
                  </div>
                  <div>
                    <Label htmlFor="description">Description (Optional)</Label>
                    <Textarea
                      id="description"
                      value={newResource.description}
                      onChange={(e) => setNewResource({ ...newResource, description: e.target.value })}
                      placeholder="What's this resource about?"
                    />
                  </div>
                  <Button onClick={handleAddResource} className="w-full">
                    Add Resource
                  </Button>
                </div>
              </DialogContent>
            </Dialog>
          </div>

          {resources.length === 0 ? (
            <p className="text-xs lg:text-sm text-muted-foreground py-8 text-center">No resources added yet. Start by adding your first learning resource!</p>
          ) : (
            <div className="space-y-3">
              {resources.map((resource) => (
                <div key={resource.id} className="flex items-start justify-between gap-3 p-3 bg-muted/50 rounded-lg">
                  <div className="min-w-0 flex-1">
                    <div className="flex items-center gap-2 mb-1">
                      <Badge variant="outline" className="text-xs flex-shrink-0">{resource.resourceType}</Badge>
                      {resource.duration && <span className="text-xs text-muted-foreground">({resource.duration}m)</span>}
                    </div>
                    <p className="font-medium text-foreground text-sm break-words">{resource.title}</p>
                    {resource.description && <p className="text-xs text-muted-foreground mt-1">{resource.description}</p>}
                    <a href={resource.url} target="_blank" rel="noopener noreferrer" className="text-xs text-accent hover:underline mt-2 inline-block break-all">
                      {resource.url}
                    </a>
                  </div>
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => handleDeleteResource(resource.id)}
                    className="flex-shrink-0"
                  >
                    <Trash2 className="w-4 h-4" />
                  </Button>
                </div>
              ))}
            </div>
          )}
        </Card>

        {/* Notes Section */}
        <Card className="card-premium p-4 lg:p-6">
          <h2 className="text-base lg:text-lg font-bold text-foreground mb-4">Personal Notes</h2>
          <div className="space-y-4">
            <div>
              <Label htmlFor="personal-notes" className="text-sm">My Notes</Label>
              <Textarea
                id="personal-notes"
                value={notes.personalNotes || ""}
                onChange={(e) => handleUpdateNotes("personalNotes", e.target.value)}
                placeholder="Write your personal notes here..."
                className="min-h-24 lg:min-h-32 text-xs lg:text-sm"
              />
            </div>
          </div>
        </Card>

        {/* Reflection Section */}
        <Card className="card-premium p-4 lg:p-6">
          <h2 className="text-base lg:text-lg font-bold text-foreground mb-4">Reflection Prompts</h2>
          <div className="space-y-4">
            <div>
              <Label htmlFor="learned" className="text-sm">What did I learn?</Label>
              <Textarea
                id="learned"
                value={notes.whatILearned || ""}
                onChange={(e) => handleUpdateNotes("whatILearned", e.target.value)}
                placeholder="Summarize what you learned in this phase..."
                className="min-h-20 lg:min-h-24 text-xs lg:text-sm"
              />
            </div>
            <div>
              <Label htmlFor="takeaways" className="text-sm">Key Takeaways</Label>
              <Textarea
                id="takeaways"
                value={notes.keyTakeaways || ""}
                onChange={(e) => handleUpdateNotes("keyTakeaways", e.target.value)}
                placeholder="What are the most important things to remember?"
                className="min-h-20 lg:min-h-24 text-xs lg:text-sm"
              />
            </div>
            <div>
              <Label htmlFor="revisit" className="text-sm">What should I revisit?</Label>
              <Textarea
                id="revisit"
                value={notes.whatToRevisit || ""}
                onChange={(e) => handleUpdateNotes("whatToRevisit", e.target.value)}
                placeholder="What topics or concepts need more practice?"
                className="min-h-20 lg:min-h-24 text-xs lg:text-sm"
              />
            </div>
          </div>
        </Card>

        {/* Navigation */}
        <div className="flex items-center justify-between gap-3">
          <Button
            variant="outline"
            onClick={handlePrevPhase}
            disabled={phaseId === 1}
            className="flex-1 text-sm"
          >
            ← Previous Phase
          </Button>
          <Button
            variant="outline"
            onClick={() => navigate("/learning-roadmap")}
            className="flex-1 text-sm"
          >
            Back to Roadmap
          </Button>
          <Button
            variant="outline"
            onClick={handleNextPhase}
            disabled={phaseId === 5}
            className="flex-1 text-sm"
          >
            Next Phase →
          </Button>
        </div>
      </div>
    </div>
  );
}
