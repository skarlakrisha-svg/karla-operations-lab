import { trpc } from "@/lib/trpc";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Textarea } from "@/components/ui/textarea";
import { StatusBadge } from "@/components/StatusBadge";
import { Progress } from "@/components/ui/progress";
import { Plus, Trash2, Edit2, ExternalLink } from "lucide-react";
import { useState } from "react";
import { toast } from "sonner";

interface FormData {
  title: string;
  resourceType: string;
  category: string;
  status: string;
  completionPercentage: number;
  priority: string;
  url: string;
  notes: string;
}

export default function Learning() {
  const { data: resources = [], isLoading, refetch } = trpc.learningResources.list.useQuery();
  const createMutation = trpc.learningResources.create.useMutation({
    onSuccess: () => {
      toast.success("Resource added");
      refetch();
      resetForm();
      setIsDialogOpen(false);
    },
  });
  const updateMutation = trpc.learningResources.update.useMutation({
    onSuccess: () => {
      toast.success("Resource updated");
      refetch();
      resetForm();
      setIsDialogOpen(false);
    },
  });
  const deleteMutation = trpc.learningResources.delete.useMutation({
    onSuccess: () => {
      toast.success("Resource deleted");
      refetch();
    },
  });

  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [editingId, setEditingId] = useState<number | null>(null);
  const [filterCategory, setFilterCategory] = useState<string>("all");
  const [filterStatus, setFilterStatus] = useState<string>("all");
  const [formData, setFormData] = useState<FormData>({
    title: "",
    resourceType: "Free Course",
    category: "GoHighLevel",
    status: "Not Started",
    completionPercentage: 0,
    priority: "Medium",
    url: "",
    notes: "",
  });

  const resetForm = () => {
    setFormData({
      title: "",
      resourceType: "Free Course",
      category: "GoHighLevel",
      status: "Not Started",
      completionPercentage: 0,
      priority: "Medium",
      url: "",
      notes: "",
    });
    setEditingId(null);
  };

  const handleOpenDialog = (resource?: any) => {
    if (resource) {
      setEditingId(resource.id);
      setFormData({
        title: resource.title,
        resourceType: resource.resourceType,
        category: resource.category,
        status: resource.status,
        completionPercentage: resource.completionPercentage || 0,
        priority: resource.priority || "Medium",
        url: resource.url || "",
        notes: resource.notes || "",
      });
    } else {
      resetForm();
    }
    setIsDialogOpen(true);
  };

  const handleSave = () => {
    if (!formData.title.trim()) {
      toast.error("Title is required");
      return;
    }

    if (editingId) {
      updateMutation.mutate({
        id: editingId,
        ...formData,
      });
    } else {
      createMutation.mutate(formData);
    }
  };

  const handleDelete = (id: number) => {
    if (confirm("Are you sure you want to delete this resource?")) {
      deleteMutation.mutate({ id });
    }
  };

  const filteredResources = resources.filter((r) => {
    const matchCategory = filterCategory === "all" || r.category === filterCategory;
    const matchStatus = filterStatus === "all" || r.status === filterStatus;
    return matchCategory && matchStatus;
  });

  const categories = Array.from(new Set(resources.map(r => r.category)));
  const statuses = Array.from(new Set(resources.map(r => r.status)));

  if (isLoading) {
    return (
      <div className="p-4 lg:p-8">
        <div className="space-y-4">
          {[1, 2, 3].map((i) => (
            <div key={i} className="h-24 bg-muted rounded-lg animate-pulse" />
          ))}
        </div>
      </div>
    );
  }

  return (
    <div className="p-4 lg:p-8 space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-foreground">Learning Hub</h1>
          <p className="text-muted-foreground mt-1">Track courses, tutorials, and research materials.</p>
        </div>
        <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
          <DialogTrigger asChild>
            <Button onClick={() => handleOpenDialog()}>
              <Plus className="w-4 h-4 mr-2" />
              Add Resource
            </Button>
          </DialogTrigger>
          <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
            <DialogHeader>
              <DialogTitle>{editingId ? "Edit Resource" : "Add Learning Resource"}</DialogTitle>
            </DialogHeader>
            <div className="space-y-4">
              <div>
                <Label htmlFor="title">Title *</Label>
                <Input
                  id="title"
                  value={formData.title}
                  onChange={(e) => setFormData({ ...formData, title: e.target.value })}
                  placeholder="e.g., Advanced React Patterns"
                  className="mt-1"
                />
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="resourceType">Resource Type</Label>
                  <Select value={formData.resourceType} onValueChange={(value) => setFormData({ ...formData, resourceType: value })}>
                    <SelectTrigger className="mt-1">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="Paid Course">Paid Course</SelectItem>
                      <SelectItem value="Free Course">Free Course</SelectItem>
                      <SelectItem value="YouTube">YouTube</SelectItem>
                      <SelectItem value="Research">Research</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <Label htmlFor="category">Category</Label>
                  <Select value={formData.category} onValueChange={(value) => setFormData({ ...formData, category: value })}>
                    <SelectTrigger className="mt-1">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="GoHighLevel">GoHighLevel</SelectItem>
                      <SelectItem value="Lovable">Lovable</SelectItem>
                      <SelectItem value="Supabase">Supabase</SelectItem>
                      <SelectItem value="Automation">Automation</SelectItem>
                      <SelectItem value="SaaS Architecture">SaaS Architecture</SelectItem>
                      <SelectItem value="Databases">Databases</SelectItem>
                      <SelectItem value="APIs">APIs</SelectItem>
                      <SelectItem value="UI/UX">UI/UX</SelectItem>
                      <SelectItem value="Zapier">Zapier</SelectItem>
                      <SelectItem value="Make">Make</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="status">Status</Label>
                  <Select value={formData.status} onValueChange={(value) => setFormData({ ...formData, status: value })}>
                    <SelectTrigger className="mt-1">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="Not Started">Not Started</SelectItem>
                      <SelectItem value="In Progress">In Progress</SelectItem>
                      <SelectItem value="Completed">Completed</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <Label htmlFor="priority">Priority</Label>
                  <Select value={formData.priority} onValueChange={(value) => setFormData({ ...formData, priority: value })}>
                    <SelectTrigger className="mt-1">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="Low">Low</SelectItem>
                      <SelectItem value="Medium">Medium</SelectItem>
                      <SelectItem value="High">High</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>

              <div>
                <Label htmlFor="completion">Completion: {formData.completionPercentage}%</Label>
                <Input
                  id="completion"
                  type="range"
                  min="0"
                  max="100"
                  value={formData.completionPercentage}
                  onChange={(e) => setFormData({ ...formData, completionPercentage: parseInt(e.target.value) })}
                  className="mt-1"
                />
              </div>

              <div>
                <Label htmlFor="url">URL</Label>
                <Input
                  id="url"
                  type="url"
                  value={formData.url}
                  onChange={(e) => setFormData({ ...formData, url: e.target.value })}
                  placeholder="https://example.com"
                  className="mt-1"
                />
              </div>

              <div>
                <Label htmlFor="notes">Notes</Label>
                <Textarea
                  id="notes"
                  value={formData.notes}
                  onChange={(e) => setFormData({ ...formData, notes: e.target.value })}
                  placeholder="Add any notes..."
                  className="mt-1"
                />
              </div>

              <Button onClick={handleSave} className="w-full">
                {editingId ? "Update Resource" : "Add Resource"}
              </Button>
            </div>
          </DialogContent>
        </Dialog>
      </div>

      {/* Filters */}
      <div className="flex gap-4 flex-wrap">
        <div className="flex-1 min-w-[200px]">
          <Label htmlFor="filterCategory" className="text-xs">Category</Label>
          <Select value={filterCategory} onValueChange={setFilterCategory}>
            <SelectTrigger className="mt-1">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Categories</SelectItem>
              {categories.map((cat) => (
                <SelectItem key={cat} value={cat}>{cat}</SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
        <div className="flex-1 min-w-[200px]">
          <Label htmlFor="filterStatus" className="text-xs">Status</Label>
          <Select value={filterStatus} onValueChange={setFilterStatus}>
            <SelectTrigger className="mt-1">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Statuses</SelectItem>
              {statuses.map((status) => (
                <SelectItem key={status} value={status}>{status}</SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
      </div>

      {/* Resources List */}
      {filteredResources.length === 0 ? (
        <Card className="card-premium p-12 text-center">
          <p className="text-muted-foreground mb-4">No resources found. Add your first learning resource!</p>
          <Button onClick={() => handleOpenDialog()}>Add Resource</Button>
        </Card>
      ) : (
        <div className="space-y-4">
          {filteredResources.map((resource) => (
            <Card key={resource.id} className="card-premium p-6">
              <div className="flex items-start justify-between mb-4">
                <div className="flex-1">
                  <div className="flex items-center gap-3 mb-2">
                    <h3 className="text-lg font-bold text-foreground">{resource.title}</h3>
                    <StatusBadge status={resource.status as any} />
                    <StatusBadge status={resource.priority as any} />
                  </div>
                  <div className="flex gap-4 text-sm text-muted-foreground">
                    <span>{resource.resourceType}</span>
                    <span>{resource.category}</span>
                  </div>
                </div>
                <div className="flex gap-2">
                  {resource.url && (
                    <a href={resource.url} target="_blank" rel="noopener noreferrer">
                      <Button size="sm" variant="outline">
                        <ExternalLink className="w-4 h-4" />
                      </Button>
                    </a>
                  )}
                  <Button
                    size="sm"
                    variant="outline"
                    onClick={() => handleOpenDialog(resource)}
                  >
                    <Edit2 className="w-4 h-4" />
                  </Button>
                  <Button
                    size="sm"
                    variant="outline"
                    onClick={() => handleDelete(resource.id)}
                  >
                    <Trash2 className="w-4 h-4" />
                  </Button>
                </div>
              </div>

              <div className="space-y-3">
                <div>
                  <div className="flex items-center justify-between mb-1">
                    <span className="text-sm text-muted-foreground">Progress</span>
                    <span className="text-sm font-semibold text-foreground">{resource.completionPercentage}%</span>
                  </div>
                  <Progress value={resource.completionPercentage} className="h-2" />
                </div>

                {resource.notes && (
                  <div className="pt-3 border-t border-border">
                    <p className="text-sm text-muted-foreground mb-1">Notes</p>
                    <p className="text-sm text-foreground">{resource.notes}</p>
                  </div>
                )}
              </div>
            </Card>
          ))}
        </div>
      )}
    </div>
  );
}
