import { trpc } from "@/lib/trpc";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Textarea } from "@/components/ui/textarea";
import { StatusBadge } from "@/components/StatusBadge";
import { Plus, Trash2, Edit2, Copy, Check } from "lucide-react";
import { useState } from "react";
import { toast } from "sonner";

interface FormData {
  title: string;
  category: string;
  promptText: string;
  tags: string;
}

export default function Prompts() {
  const { data: prompts = [], isLoading, refetch } = trpc.prompts.list.useQuery();
  const createMutation = trpc.prompts.create.useMutation({
    onSuccess: () => {
      toast.success("Prompt added");
      refetch();
      resetForm();
      setIsDialogOpen(false);
    },
  });
  const updateMutation = trpc.prompts.update.useMutation({
    onSuccess: () => {
      toast.success("Prompt updated");
      refetch();
      resetForm();
      setIsDialogOpen(false);
    },
  });
  const deleteMutation = trpc.prompts.delete.useMutation({
    onSuccess: () => {
      toast.success("Prompt deleted");
      refetch();
    },
  });

  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [editingId, setEditingId] = useState<number | null>(null);
  const [filterCategory, setFilterCategory] = useState<string>("all");
  const [copiedId, setCopiedId] = useState<number | null>(null);
  const [formData, setFormData] = useState<FormData>({
    title: "",
    category: "ChatGPT",
    promptText: "",
    tags: "",
  });

  const resetForm = () => {
    setFormData({
      title: "",
      category: "ChatGPT",
      promptText: "",
      tags: "",
    });
    setEditingId(null);
  };

  const handleOpenDialog = (prompt?: any) => {
    if (prompt) {
      setEditingId(prompt.id);
      setFormData({
        title: prompt.title,
        category: prompt.category,
        promptText: prompt.promptText,
        tags: prompt.tags || "",
      });
    } else {
      resetForm();
    }
    setIsDialogOpen(true);
  };

  const handleSave = () => {
    if (!formData.title.trim()) {
      toast.error("Title is required");
      return;
    }
    if (!formData.promptText.trim()) {
      toast.error("Prompt text is required");
      return;
    }

    if (editingId) {
      updateMutation.mutate({
        id: editingId,
        ...formData,
      });
    } else {
      createMutation.mutate(formData);
    }
  };

  const handleDelete = (id: number) => {
    if (confirm("Are you sure you want to delete this prompt?")) {
      deleteMutation.mutate({ id });
    }
  };

  const handleCopyToClipboard = (text: string, id: number) => {
    navigator.clipboard.writeText(text).then(() => {
      setCopiedId(id);
      toast.success("Copied to clipboard");
      setTimeout(() => setCopiedId(null), 2000);
    });
  };

  const filteredPrompts = prompts.filter((p) => {
    const matchCategory = filterCategory === "all" || p.category === filterCategory;
    return matchCategory;
  });

  const categories = Array.from(new Set(prompts.map(p => p.category)));

  if (isLoading) {
    return (
      <div className="p-4 lg:p-8">
        <div className="space-y-4">
          {[1, 2, 3].map((i) => (
            <div key={i} className="h-24 bg-muted rounded-lg animate-pulse" />
          ))}
        </div>
      </div>
    );
  }

  return (
    <div className="p-4 lg:p-8 space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-foreground">Prompt Library</h1>
          <p className="text-muted-foreground mt-1">Store and organize prompts for your AI tools.</p>
        </div>
        <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
          <DialogTrigger asChild>
            <Button onClick={() => handleOpenDialog()}>
              <Plus className="w-4 h-4 mr-2" />
              Add Prompt
            </Button>
          </DialogTrigger>
          <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
            <DialogHeader>
              <DialogTitle>{editingId ? "Edit Prompt" : "Add New Prompt"}</DialogTitle>
            </DialogHeader>
            <div className="space-y-4">
              <div>
                <Label htmlFor="title">Title *</Label>
                <Input
                  id="title"
                  value={formData.title}
                  onChange={(e) => setFormData({ ...formData, title: e.target.value })}
                  placeholder="e.g., Content Outline Generator"
                  className="mt-1"
                />
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="category">Category</Label>
                  <Select value={formData.category} onValueChange={(value) => setFormData({ ...formData, category: value })}>
                    <SelectTrigger className="mt-1">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="Manus">Manus</SelectItem>
                      <SelectItem value="ChatGPT">ChatGPT</SelectItem>
                      <SelectItem value="Lovable">Lovable</SelectItem>
                      <SelectItem value="Zapier">Zapier</SelectItem>
                      <SelectItem value="Make">Make</SelectItem>
                      <SelectItem value="GoHighLevel">GoHighLevel</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <Label htmlFor="tags">Tags</Label>
                  <Input
                    id="tags"
                    value={formData.tags}
                    onChange={(e) => setFormData({ ...formData, tags: e.target.value })}
                    placeholder="e.g., content, writing, seo"
                    className="mt-1"
                  />
                </div>
              </div>

              <div>
                <Label htmlFor="promptText">Prompt Text *</Label>
                <Textarea
                  id="promptText"
                  value={formData.promptText}
                  onChange={(e) => setFormData({ ...formData, promptText: e.target.value })}
                  placeholder="Enter your prompt here..."
                  className="mt-1 min-h-[200px]"
                />
              </div>

              <Button onClick={handleSave} className="w-full">
                {editingId ? "Update Prompt" : "Add Prompt"}
              </Button>
            </div>
          </DialogContent>
        </Dialog>
      </div>

      {/* Filters */}
      {categories.length > 0 && (
        <div className="flex gap-4 flex-wrap">
          <div className="flex-1 min-w-[200px]">
            <Label htmlFor="filterCategory" className="text-xs">Category</Label>
            <Select value={filterCategory} onValueChange={setFilterCategory}>
              <SelectTrigger className="mt-1">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Categories</SelectItem>
                {categories.map((cat) => (
                  <SelectItem key={cat} value={cat}>{cat}</SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
        </div>
      )}

      {/* Prompts List */}
      {filteredPrompts.length === 0 ? (
        <Card className="card-premium p-12 text-center">
          <p className="text-muted-foreground mb-4">No prompts yet. Add your first prompt!</p>
          <Button onClick={() => handleOpenDialog()}>Add Prompt</Button>
        </Card>
      ) : (
        <div className="space-y-4">
          {filteredPrompts.map((prompt) => (
            <Card key={prompt.id} className="card-premium p-6">
              <div className="flex items-start justify-between mb-4">
                <div className="flex-1">
                  <div className="flex items-center gap-3 mb-2">
                    <h3 className="text-lg font-bold text-foreground">{prompt.title}</h3>
                    <StatusBadge status={prompt.category as any} />
                  </div>
                  {prompt.tags && (
                    <div className="flex gap-2 flex-wrap mt-2">
                      {prompt.tags.split(",").map((tag, idx) => (
                        <span key={idx} className="text-xs bg-muted text-muted-foreground px-2 py-1 rounded-full">
                          {tag.trim()}
                        </span>
                      ))}
                    </div>
                  )}
                </div>
                <div className="flex gap-2">
                  <Button
                    size="sm"
                    variant="outline"
                    onClick={() => handleCopyToClipboard(prompt.promptText, prompt.id)}
                    title="Copy to clipboard"
                  >
                    {copiedId === prompt.id ? (
                      <Check className="w-4 h-4 text-accent" />
                    ) : (
                      <Copy className="w-4 h-4" />
                    )}
                  </Button>
                  <Button
                    size="sm"
                    variant="outline"
                    onClick={() => handleOpenDialog(prompt)}
                  >
                    <Edit2 className="w-4 h-4" />
                  </Button>
                  <Button
                    size="sm"
                    variant="outline"
                    onClick={() => handleDelete(prompt.id)}
                  >
                    <Trash2 className="w-4 h-4" />
                  </Button>
                </div>
              </div>

              <div className="bg-muted rounded-lg p-4 mt-4">
                <p className="text-sm text-foreground whitespace-pre-wrap font-mono">{prompt.promptText}</p>
              </div>
            </Card>
          ))}
        </div>
      )}
    </div>
  );
}
