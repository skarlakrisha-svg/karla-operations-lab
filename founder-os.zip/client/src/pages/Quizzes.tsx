import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Label } from "@/components/ui/label";
import { BookOpen, CheckCircle, XCircle, ArrowLeft, RotateCcw } from "lucide-react";
import { useState } from "react";

interface Question {
  id: string;
  question: string;
  options: string[];
  correctAnswer: number;
  explanation: string;
}

interface Quiz {
  id: number;
  phaseId: number;
  phaseName: string;
  title: string;
  description: string;
  questions: Question[];
  passingScore: number;
  timeLimit?: number;
}

const SAMPLE_QUIZZES: Quiz[] = [
  {
    id: 1,
    phaseId: 1,
    phaseName: "Phase 1: Foundation",
    title: "Foundation Fundamentals Quiz",
    description: "Test your knowledge of foundation concepts",
    passingScore: 70,
    timeLimit: 15,
    questions: [
      {
        id: "q1",
        question: "What is the primary goal of SaaS?",
        options: [
          "To sell software licenses",
          "To provide software as a service via the internet",
          "To build desktop applications",
          "To create mobile apps only",
        ],
        correctAnswer: 1,
        explanation: "SaaS (Software as a Service) delivers software applications over the internet on a subscription basis.",
      },
      {
        id: "q2",
        question: "Which tool is used for building internal dashboards?",
        options: ["Lovable", "Zapier", "Make", "GoHighLevel"],
        correctAnswer: 0,
        explanation: "Lovable is designed for building beautiful internal dashboards and applications.",
      },
      {
        id: "q3",
        question: "What does MVP stand for?",
        options: [
          "Most Valuable Product",
          "Minimum Viable Product",
          "Maximum Value Platform",
          "Multi-Version Program",
        ],
        correctAnswer: 1,
        explanation: "MVP (Minimum Viable Product) is the simplest version of a product that can still satisfy customers.",
      },
    ],
  },
];

type QuizState = "list" | "taking" | "results";

export default function Quizzes() {
  const [state, setState] = useState<QuizState>("list");
  const [selectedQuiz, setSelectedQuiz] = useState<Quiz | null>(null);
  const [currentQuestion, setCurrentQuestion] = useState(0);
  const [answers, setAnswers] = useState<Record<string, number>>({});
  const [score, setScore] = useState(0);

  const quizzes = SAMPLE_QUIZZES;

  const handleStartQuiz = (quiz: Quiz) => {
    setSelectedQuiz(quiz);
    setCurrentQuestion(0);
    setAnswers({});
    setState("taking");
  };

  const handleSelectAnswer = (questionId: string, answerIndex: number) => {
    setAnswers({
      ...answers,
      [questionId]: answerIndex,
    });
  };

  const handleNextQuestion = () => {
    if (currentQuestion < (selectedQuiz?.questions.length || 0) - 1) {
      setCurrentQuestion(currentQuestion + 1);
    }
  };

  const handlePreviousQuestion = () => {
    if (currentQuestion > 0) {
      setCurrentQuestion(currentQuestion - 1);
    }
  };

  const handleSubmitQuiz = () => {
    if (!selectedQuiz) return;

    let correctCount = 0;
    selectedQuiz.questions.forEach((q) => {
      if (answers[q.id] === q.correctAnswer) {
        correctCount++;
      }
    });

    const percentage = Math.round((correctCount / selectedQuiz.questions.length) * 100);
    setScore(percentage);
    setState("results");
  };

  const handleRetakeQuiz = () => {
    handleStartQuiz(selectedQuiz!);
  };

  const handleBackToList = () => {
    setState("list");
    setSelectedQuiz(null);
    setCurrentQuestion(0);
    setAnswers({});
  };

  // Quiz List View
  if (state === "list") {
    return (
      <div className="p-4 lg:p-8 space-y-6">
        {/* Header */}
        <div>
          <h1 className="text-3xl font-bold text-foreground">Learning Quizzes</h1>
          <p className="text-muted-foreground mt-1">
            Test your knowledge and earn enhanced certificates by completing phase quizzes.
          </p>
        </div>

        {/* Quizzes Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {quizzes.map((quiz) => (
            <Card key={quiz.id} className="card-premium p-6">
              <div className="space-y-4">
                {/* Header */}
                <div className="flex items-start justify-between">
                  <div className="space-y-1">
                    <h3 className="font-semibold text-foreground">{quiz.title}</h3>
                    <p className="text-sm text-muted-foreground">{quiz.phaseName}</p>
                  </div>
                  <Badge className="bg-accent/10 text-accent border-accent/30">
                    {quiz.questions.length} Q
                  </Badge>
                </div>

                {/* Description */}
                <p className="text-sm text-muted-foreground">{quiz.description}</p>

                {/* Details */}
                <div className="flex gap-4 text-sm">
                  <div className="flex items-center gap-1 text-muted-foreground">
                    <BookOpen className="w-4 h-4" />
                    {quiz.passingScore}% to pass
                  </div>
                  {quiz.timeLimit && (
                    <div className="flex items-center gap-1 text-muted-foreground">
                      <span>⏱️</span>
                      {quiz.timeLimit} min
                    </div>
                  )}
                </div>

                {/* Action */}
                <Button
                  onClick={() => handleStartQuiz(quiz)}
                  className="w-full"
                >
                  Start Quiz
                </Button>
              </div>
            </Card>
          ))}
        </div>

        {/* Empty State */}
        {quizzes.length === 0 && (
          <Card className="card-premium p-12 text-center">
            <BookOpen className="w-12 h-12 text-muted-foreground/50 mx-auto mb-4" />
            <h3 className="text-lg font-semibold text-foreground mb-2">No Quizzes Available</h3>
            <p className="text-muted-foreground">
              Quizzes will be available as you progress through phases.
            </p>
          </Card>
        )}
      </div>
    );
  }

  // Quiz Taking View
  if (state === "taking" && selectedQuiz) {
    const question = selectedQuiz.questions[currentQuestion];
    const progress = ((currentQuestion + 1) / selectedQuiz.questions.length) * 100;
    const isAnswered = answers[question.id] !== undefined;

    return (
      <div className="p-4 lg:p-8 space-y-6 max-w-2xl mx-auto">
        {/* Back Button */}
        <button
          onClick={handleBackToList}
          className="flex items-center gap-2 text-accent hover:text-accent/80 transition-colors"
        >
          <ArrowLeft className="w-4 h-4" />
          Back to Quizzes
        </button>

        {/* Quiz Header */}
        <Card className="card-premium p-6">
          <div className="space-y-4">
            <div className="flex items-start justify-between">
              <div>
                <h2 className="text-2xl font-bold text-foreground">{selectedQuiz.title}</h2>
                <p className="text-sm text-muted-foreground">{selectedQuiz.phaseName}</p>
              </div>
              <Badge className="bg-accent/10 text-accent border-accent/30">
                Q {currentQuestion + 1}/{selectedQuiz.questions.length}
              </Badge>
            </div>
            <Progress value={progress} className="h-2" />
          </div>
        </Card>

        {/* Question */}
        <Card className="card-premium p-8">
          <div className="space-y-6">
            {/* Question Text */}
            <h3 className="text-xl font-semibold text-foreground">{question.question}</h3>

            {/* Options */}
            <RadioGroup
              value={answers[question.id]?.toString() || ""}
              onValueChange={(value) => handleSelectAnswer(question.id, parseInt(value))}
            >
              <div className="space-y-3">
                {question.options.map((option, idx) => (
                  <div key={idx} className="flex items-center space-x-3 p-4 rounded-lg border border-border hover:border-accent/50 hover:bg-muted/50 transition-all cursor-pointer">
                    <RadioGroupItem value={idx.toString()} id={`option-${idx}`} />
                    <Label htmlFor={`option-${idx}`} className="flex-1 cursor-pointer text-foreground">
                      {option}
                    </Label>
                  </div>
                ))}
              </div>
            </RadioGroup>
          </div>
        </Card>

        {/* Navigation */}
        <div className="flex gap-3 justify-between">
          <Button
            variant="outline"
            onClick={handlePreviousQuestion}
            disabled={currentQuestion === 0}
          >
            Previous
          </Button>

          {currentQuestion === selectedQuiz.questions.length - 1 ? (
            <Button
              onClick={handleSubmitQuiz}
              disabled={Object.keys(answers).length !== selectedQuiz.questions.length}
            >
              Submit Quiz
            </Button>
          ) : (
            <Button
              onClick={handleNextQuestion}
              disabled={!isAnswered}
            >
              Next
            </Button>
          )}
        </div>
      </div>
    );
  }

  // Results View
  if (state === "results" && selectedQuiz) {
    const passed = score >= selectedQuiz.passingScore;
    const correctCount = Object.entries(answers).filter(
      ([qId, answerIdx]) => {
        const q = selectedQuiz.questions.find((q) => q.id === qId);
        return q && answerIdx === q.correctAnswer;
      }
    ).length;

    return (
      <div className="p-4 lg:p-8 space-y-6 max-w-2xl mx-auto">
        {/* Results Card */}
        <Card
          className={`card-premium p-8 text-center space-y-6 border-2 ${
            passed ? "border-accent/30 bg-accent/5" : "border-destructive/30 bg-destructive/5"
          }`}
        >
          {/* Icon */}
          {passed ? (
            <CheckCircle className="w-16 h-16 text-accent mx-auto" />
          ) : (
            <XCircle className="w-16 h-16 text-destructive mx-auto" />
          )}

          {/* Status */}
          <div className="space-y-2">
            <h2 className="text-3xl font-bold text-foreground">
              {passed ? "Quiz Passed! 🎉" : "Quiz Failed"}
            </h2>
            <p className="text-muted-foreground">
              {passed
                ? "Great job! You've demonstrated mastery of this phase."
                : "Keep learning and try again!"}
            </p>
          </div>

          {/* Score */}
          <div className="space-y-2">
            <p className="text-5xl font-bold text-accent">{score}%</p>
            <p className="text-muted-foreground">
              {correctCount} out of {selectedQuiz.questions.length} correct
            </p>
          </div>

          {/* Passing Score */}
          <div className="pt-4 border-t border-border">
            <p className="text-sm text-muted-foreground">
              Passing score: {selectedQuiz.passingScore}%
            </p>
          </div>
        </Card>

        {/* Review Answers */}
        <Card className="card-premium p-6">
          <h3 className="font-semibold text-foreground mb-4">Answer Review</h3>
          <div className="space-y-4">
            {selectedQuiz.questions.map((q, idx) => {
              const userAnswer = answers[q.id];
              const isCorrect = userAnswer === q.correctAnswer;
              return (
                <div
                  key={q.id}
                  className={`p-4 rounded-lg border-2 ${
                    isCorrect
                      ? "border-accent/30 bg-accent/5"
                      : "border-destructive/30 bg-destructive/5"
                  }`}
                >
                  <div className="flex items-start gap-3 mb-2">
                    {isCorrect ? (
                      <CheckCircle className="w-5 h-5 text-accent flex-shrink-0 mt-0.5" />
                    ) : (
                      <XCircle className="w-5 h-5 text-destructive flex-shrink-0 mt-0.5" />
                    )}
                    <div className="flex-1">
                      <p className="font-semibold text-foreground">Q{idx + 1}: {q.question}</p>
                      <p className="text-sm text-muted-foreground mt-1">
                        Your answer: {q.options[userAnswer || 0]}
                      </p>
                      {!isCorrect && (
                        <p className="text-sm text-accent font-semibold mt-1">
                          Correct answer: {q.options[q.correctAnswer]}
                        </p>
                      )}
                      <p className="text-sm text-muted-foreground mt-2">{q.explanation}</p>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        </Card>

        {/* Actions */}
        <div className="flex gap-3">
          <Button
            variant="outline"
            onClick={handleBackToList}
            className="flex-1"
          >
            Back to Quizzes
          </Button>
          {!passed && (
            <Button
              onClick={handleRetakeQuiz}
              className="flex-1 gap-2"
            >
              <RotateCcw className="w-4 h-4" />
              Retake Quiz
            </Button>
          )}
        </div>
      </div>
    );
  }

  return null;
}
