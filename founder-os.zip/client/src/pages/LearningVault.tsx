import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Plus, ExternalLink, Trash2, Edit2 } from "lucide-react";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Progress } from "@/components/ui/progress";
import { useState } from "react";
import { toast } from "sonner";

interface VaultItem {
  id: string;
  title: string;
  link?: string;
  notes?: string;
  progress: number;
  priority: "High" | "Medium" | "Low";
  toolCategory?: string;
  status: "Not Started" | "In Progress" | "Completed";
}

const sampleVaultItems: Record<string, VaultItem[]> = {
  paid: [
    {
      id: "1",
      title: "Advanced React Patterns Course",
      link: "https://example.com/react",
      notes: "Focus on hooks and state management",
      progress: 45,
      priority: "High",
      toolCategory: "Lovable",
      status: "In Progress",
    },
    {
      id: "2",
      title: "SaaS Fundamentals Masterclass",
      link: "https://example.com/saas",
      notes: "Business model and growth strategies",
      progress: 20,
      priority: "High",
      toolCategory: "SaaS Architecture",
      status: "In Progress",
    },
  ],
  free: [
    {
      id: "3",
      title: "Next.js Official Documentation",
      link: "https://nextjs.org/docs",
      notes: "Reference for framework features",
      progress: 60,
      priority: "Medium",
      toolCategory: "Lovable",
      status: "In Progress",
    },
    {
      id: "4",
      title: "PostgreSQL Basics",
      link: "https://example.com/postgres",
      notes: "Database fundamentals",
      progress: 30,
      priority: "High",
      toolCategory: "Databases",
      status: "In Progress",
    },
  ],
  youtube: [
    {
      id: "5",
      title: "Building a SaaS from Scratch",
      link: "https://youtube.com/example",
      notes: "Full walkthrough of SaaS development",
      progress: 50,
      priority: "High",
      toolCategory: "SaaS Architecture",
      status: "In Progress",
    },
    {
      id: "6",
      title: "Zapier Automation Tutorials",
      link: "https://youtube.com/zapier",
      notes: "Practical automation examples",
      progress: 35,
      priority: "Medium",
      toolCategory: "Zapier",
      status: "In Progress",
    },
  ],
  research: [
    {
      id: "7",
      title: "State of SaaS 2024 Report",
      link: "https://example.com/report",
      notes: "Market trends and insights",
      progress: 80,
      priority: "Medium",
      toolCategory: "SaaS Architecture",
      status: "Completed",
    },
  ],
  ai: [
    {
      id: "8",
      title: "ChatGPT Prompt Engineering Guide",
      link: "https://example.com/prompts",
      notes: "Advanced prompt techniques",
      progress: 70,
      priority: "High",
      toolCategory: "ChatGPT",
      status: "In Progress",
    },
  ],
  prompts: [
    {
      id: "9",
      title: "SaaS Ideation Prompt",
      notes: "Generate SaaS ideas using ChatGPT",
      progress: 100,
      priority: "Medium",
      toolCategory: "ChatGPT",
      status: "Completed",
    },
  ],
  saasIdeas: [
    {
      id: "10",
      title: "Property Management Automation",
      notes: "Automated tenant communication and payment tracking",
      progress: 30,
      priority: "High",
      toolCategory: "SaaS Architecture",
      status: "In Progress",
    },
    {
      id: "11",
      title: "AI-Powered Content Creator Dashboard",
      notes: "Analytics and scheduling for content creators",
      progress: 15,
      priority: "Medium",
      toolCategory: "SaaS Architecture",
      status: "Not Started",
    },
  ],
  automationIdeas: [
    {
      id: "12",
      title: "Lead Scoring Workflow",
      notes: "Automatically score leads based on engagement",
      progress: 40,
      priority: "High",
      toolCategory: "Zapier",
      status: "In Progress",
    },
  ],
};

function VaultItemCard({ item, onEdit, onDelete }: { item: VaultItem; onEdit: (item: VaultItem) => void; onDelete: (id: string) => void }) {
  const statusColors: Record<string, string> = {
    "Not Started": "bg-muted text-muted-foreground",
    "In Progress": "bg-accent/10 text-accent",
    "Completed": "bg-green-500/10 text-green-600 dark:text-green-400",
  };

  const priorityColors: Record<string, string> = {
    High: "bg-destructive/10 text-destructive",
    Medium: "bg-blue-500/10 text-blue-600 dark:text-blue-400",
    Low: "bg-muted text-muted-foreground",
  };

  return (
    <Card className="card-premium p-4">
      <div className="flex items-start justify-between mb-3">
        <div className="flex-1">
          <h3 className="font-bold text-foreground">{item.title}</h3>
          <div className="flex gap-2 mt-2 flex-wrap">
            <span className={`text-xs px-2 py-1 rounded-full ${statusColors[item.status]}`}>
              {item.status}
            </span>
            <span className={`text-xs px-2 py-1 rounded-full ${priorityColors[item.priority]}`}>
              {item.priority}
            </span>
            {item.toolCategory && (
              <span className="text-xs px-2 py-1 rounded-full bg-muted text-muted-foreground">
                {item.toolCategory}
              </span>
            )}
          </div>
        </div>
        <div className="flex gap-1">
          {item.link && (
            <a href={item.link} target="_blank" rel="noopener noreferrer">
              <Button size="sm" variant="outline">
                <ExternalLink className="w-4 h-4" />
              </Button>
            </a>
          )}
          <Button size="sm" variant="outline" onClick={() => onEdit(item)}>
            <Edit2 className="w-4 h-4" />
          </Button>
          <Button size="sm" variant="outline" onClick={() => onDelete(item.id)}>
            <Trash2 className="w-4 h-4" />
          </Button>
        </div>
      </div>

      {item.notes && (
        <p className="text-sm text-muted-foreground mb-3">{item.notes}</p>
      )}

      <div>
        <div className="flex items-center justify-between mb-1">
          <span className="text-xs text-muted-foreground">Progress</span>
          <span className="text-xs font-semibold text-foreground">{item.progress}%</span>
        </div>
        <Progress value={item.progress} className="h-2" />
      </div>
    </Card>
  );
}

export default function LearningVault() {
  const [vaultItems, setVaultItems] = useState(sampleVaultItems);
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [editingItem, setEditingItem] = useState<VaultItem | null>(null);
  const [currentTab, setCurrentTab] = useState("paid");

  const handleEdit = (item: VaultItem) => {
    setEditingItem(item);
    setIsDialogOpen(true);
  };

  const handleDelete = (id: string) => {
    if (confirm("Are you sure you want to delete this item?")) {
      setVaultItems(prev => ({
        ...prev,
        [currentTab]: prev[currentTab as keyof typeof prev].filter(item => item.id !== id)
      }));
      toast.success("Item deleted");
    }
  };

  const handleAddNew = () => {
    setEditingItem(null);
    setIsDialogOpen(true);
  };

  return (
    <div className="p-4 lg:p-8 space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-foreground">Learning Vault</h1>
          <p className="text-muted-foreground mt-1">
            Your centralized repository of learning resources, ideas, and prompts organized by type.
          </p>
        </div>
        <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
          <DialogTrigger asChild>
            <Button onClick={handleAddNew}>
              <Plus className="w-4 h-4 mr-2" />
              Add Resource
            </Button>
          </DialogTrigger>
          <DialogContent className="max-w-2xl">
            <DialogHeader>
              <DialogTitle>{editingItem ? "Edit Resource" : "Add Learning Resource"}</DialogTitle>
            </DialogHeader>
            <div className="space-y-4">
              <div>
                <Label>Title</Label>
                <Input placeholder="Resource title" className="mt-1" />
              </div>
              <div>
                <Label>Link (optional)</Label>
                <Input placeholder="https://example.com" type="url" className="mt-1" />
              </div>
              <div>
                <Label>Notes</Label>
                <Textarea placeholder="Add notes..." className="mt-1" />
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label>Priority</Label>
                  <Select defaultValue="Medium">
                    <SelectTrigger className="mt-1">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="High">High</SelectItem>
                      <SelectItem value="Medium">Medium</SelectItem>
                      <SelectItem value="Low">Low</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <Label>Status</Label>
                  <Select defaultValue="Not Started">
                    <SelectTrigger className="mt-1">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="Not Started">Not Started</SelectItem>
                      <SelectItem value="In Progress">In Progress</SelectItem>
                      <SelectItem value="Completed">Completed</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>
              <Button className="w-full">Save Resource</Button>
            </div>
          </DialogContent>
        </Dialog>
      </div>

      {/* Tabs */}
      <Tabs value={currentTab} onValueChange={setCurrentTab} className="w-full">
        <TabsList className="grid w-full grid-cols-4 lg:grid-cols-8">
          <TabsTrigger value="paid">Paid</TabsTrigger>
          <TabsTrigger value="free">Free</TabsTrigger>
          <TabsTrigger value="youtube">YouTube</TabsTrigger>
          <TabsTrigger value="research">Research</TabsTrigger>
          <TabsTrigger value="ai">AI Recs</TabsTrigger>
          <TabsTrigger value="prompts">Prompts</TabsTrigger>
          <TabsTrigger value="saasIdeas">SaaS Ideas</TabsTrigger>
          <TabsTrigger value="automationIdeas">Auto Ideas</TabsTrigger>
        </TabsList>

        {/* Paid Courses */}
        <TabsContent value="paid" className="space-y-4 mt-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {vaultItems.paid.map((item) => (
              <VaultItemCard key={item.id} item={item} onEdit={handleEdit} onDelete={handleDelete} />
            ))}
          </div>
        </TabsContent>

        {/* Free Courses */}
        <TabsContent value="free" className="space-y-4 mt-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {vaultItems.free.map((item) => (
              <VaultItemCard key={item.id} item={item} onEdit={handleEdit} onDelete={handleDelete} />
            ))}
          </div>
        </TabsContent>

        {/* YouTube */}
        <TabsContent value="youtube" className="space-y-4 mt-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {vaultItems.youtube.map((item) => (
              <VaultItemCard key={item.id} item={item} onEdit={handleEdit} onDelete={handleDelete} />
            ))}
          </div>
        </TabsContent>

        {/* Research */}
        <TabsContent value="research" className="space-y-4 mt-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {vaultItems.research.map((item) => (
              <VaultItemCard key={item.id} item={item} onEdit={handleEdit} onDelete={handleDelete} />
            ))}
          </div>
        </TabsContent>

        {/* AI Recommendations */}
        <TabsContent value="ai" className="space-y-4 mt-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {vaultItems.ai.map((item) => (
              <VaultItemCard key={item.id} item={item} onEdit={handleEdit} onDelete={handleDelete} />
            ))}
          </div>
        </TabsContent>

        {/* Prompt Vault */}
        <TabsContent value="prompts" className="space-y-4 mt-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {vaultItems.prompts.map((item) => (
              <VaultItemCard key={item.id} item={item} onEdit={handleEdit} onDelete={handleDelete} />
            ))}
          </div>
        </TabsContent>

        {/* SaaS Ideas */}
        <TabsContent value="saasIdeas" className="space-y-4 mt-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {vaultItems.saasIdeas.map((item) => (
              <VaultItemCard key={item.id} item={item} onEdit={handleEdit} onDelete={handleDelete} />
            ))}
          </div>
        </TabsContent>

        {/* Automation Ideas */}
        <TabsContent value="automationIdeas" className="space-y-4 mt-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {vaultItems.automationIdeas.map((item) => (
              <VaultItemCard key={item.id} item={item} onEdit={handleEdit} onDelete={handleDelete} />
            ))}
          </div>
        </TabsContent>
      </Tabs>
    </div>
  );
}
