import { Toaster } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import { Route, Switch } from "wouter";
import ErrorBoundary from "./components/ErrorBoundary";
import { ThemeProvider } from "./contexts/ThemeContext";
import { MainLayout } from "./components/Navigation";
import Dashboard from "./pages/Dashboard";
import LearningRoadmap from "./pages/LearningRoadmap";
import PhaseDetail from "./pages/PhaseDetail";
import ToolEcosystem from "./pages/ToolEcosystem";
import Roadmap from "./pages/Roadmap";
import LearningVault from "./pages/LearningVault";
import Planner from "./pages/Planner";
import Certificates from "./pages/Certificates";
import Quizzes from "./pages/Quizzes";
import Community from "./pages/Community";
import NotFound from "./pages/NotFound";

function Router() {
  return (
    <Switch>
      <Route path="/" component={Dashboard} />
      <Route path="/learning-roadmap" component={LearningRoadmap} />
      <Route path="/phase/:id" component={PhaseDetail} />
      <Route path="/tools" component={ToolEcosystem} />
      <Route path="/roadmap" component={Roadmap} />
      <Route path="/vault" component={LearningVault} />
      <Route path="/planner" component={Planner} />
      <Route path="/certificates" component={Certificates} />
      <Route path="/quizzes" component={Quizzes} />
      <Route path="/community" component={Community} />
      <Route path="/404" component={NotFound} />
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  return (
    <ErrorBoundary>
      <ThemeProvider defaultTheme="dark" switchable>
        <TooltipProvider>
          <Toaster />
          <MainLayout>
            <Router />
          </MainLayout>
        </TooltipProvider>
      </ThemeProvider>
    </ErrorBoundary>
  );
}

export default App;
