import { COOKIE_NAME } from "@shared/const";
import { getSessionCookieOptions } from "./_core/cookies";
import { systemRouter } from "./_core/systemRouter";
import { publicProcedure, router, protectedProcedure } from "./_core/trpc";
import { z } from "zod";
import * as db from "./db";

export const appRouter = router({
  system: systemRouter,
  auth: router({
    me: publicProcedure.query(opts => opts.ctx.user),
    logout: publicProcedure.mutation(({ ctx }) => {
      const cookieOptions = getSessionCookieOptions(ctx.req);
      ctx.res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 });
      return {
        success: true,
      } as const;
    }),
  }),

  // ============ SUBSCRIPTIONS ============
  subscriptions: router({
    list: protectedProcedure.query(({ ctx }) => db.getUserSubscriptions(ctx.user.id)),
    
    create: protectedProcedure
      .input(z.object({
        toolName: z.string().min(1),
        category: z.string().min(1),
        status: z.enum(["Active", "Trial", "Deferred", "Cancelled"]).default("Active"),
        monthlyCost: z.string().optional(),
        trialStartDate: z.string().optional(),
        trialEndDate: z.string().optional(),
        renewalDate: z.string().optional(),
        loginEmail: z.string().email().optional().or(z.literal("")),
        continueOrCancel: z.enum(["Continue", "Cancel", "Undecided"]).default("Undecided"),
        notes: z.string().optional(),
      }))
      .mutation(({ ctx, input }) => {
        return db.createSubscription(ctx.user.id, {
          toolName: input.toolName,
          category: input.category,
          status: input.status,
          monthlyCost: input.monthlyCost || undefined,
          trialStartDate: input.trialStartDate ? new Date(input.trialStartDate) : undefined,
          trialEndDate: input.trialEndDate ? new Date(input.trialEndDate) : undefined,
          renewalDate: input.renewalDate ? new Date(input.renewalDate) : undefined,
          loginEmail: input.loginEmail || undefined,
          continueOrCancel: input.continueOrCancel,
          notes: input.notes,
        });
      }),

    update: protectedProcedure
      .input(z.object({
        id: z.number(),
        toolName: z.string().min(1).optional(),
        category: z.string().min(1).optional(),
        status: z.enum(["Active", "Trial", "Deferred", "Cancelled"]).optional(),
        monthlyCost: z.string().optional(),
        trialStartDate: z.string().optional(),
        trialEndDate: z.string().optional(),
        renewalDate: z.string().optional(),
        loginEmail: z.string().email().optional().or(z.literal("")),
        continueOrCancel: z.enum(["Continue", "Cancel", "Undecided"]).optional(),
        notes: z.string().optional(),
      }))
      .mutation(({ ctx, input }) => {
        const { id, ...data } = input;
        return db.updateSubscription(id, ctx.user.id, {
          toolName: data.toolName,
          category: data.category,
          status: data.status,
          monthlyCost: data.monthlyCost || undefined,
          trialStartDate: data.trialStartDate ? new Date(data.trialStartDate) : undefined,
          trialEndDate: data.trialEndDate ? new Date(data.trialEndDate) : undefined,
          renewalDate: data.renewalDate ? new Date(data.renewalDate) : undefined,
          loginEmail: data.loginEmail || undefined,
          continueOrCancel: data.continueOrCancel,
          notes: data.notes,
        });
      }),

    delete: protectedProcedure
      .input(z.object({ id: z.number() }))
      .mutation(({ ctx, input }) => db.deleteSubscription(input.id, ctx.user.id)),
  }),

  // ============ LEARNING RESOURCES ============
  learningResources: router({
    list: protectedProcedure.query(({ ctx }) => db.getUserLearningResources(ctx.user.id)),
    
    create: protectedProcedure
      .input(z.object({
        title: z.string().min(1),
        resourceType: z.enum(["Paid Course", "Free Course", "YouTube", "Research"]),
        category: z.enum(["GoHighLevel", "Lovable", "Supabase", "Automation", "SaaS Architecture", "Databases", "APIs", "UI/UX", "Zapier", "Make"]),
        status: z.enum(["Not Started", "In Progress", "Completed"]).default("Not Started"),
        completionPercentage: z.number().min(0).max(100).default(0),
        priority: z.enum(["Low", "Medium", "High"]).default("Medium"),
        url: z.string().optional(),
        notes: z.string().optional(),
      }))
      .mutation(({ ctx, input }) => db.createLearningResource(ctx.user.id, input)),

    update: protectedProcedure
      .input(z.object({
        id: z.number(),
        title: z.string().min(1).optional(),
        resourceType: z.enum(["Paid Course", "Free Course", "YouTube", "Research"]).optional(),
        category: z.enum(["GoHighLevel", "Lovable", "Supabase", "Automation", "SaaS Architecture", "Databases", "APIs", "UI/UX", "Zapier", "Make"]).optional(),
        status: z.enum(["Not Started", "In Progress", "Completed"]).optional(),
        completionPercentage: z.number().min(0).max(100).optional(),
        priority: z.enum(["Low", "Medium", "High"]).optional(),
        url: z.string().optional(),
        notes: z.string().optional(),
      }))
      .mutation(({ ctx, input }) => {
        const { id, ...data } = input;
        return db.updateLearningResource(id, ctx.user.id, data);
      }),

    delete: protectedProcedure
      .input(z.object({ id: z.number() }))
      .mutation(({ ctx, input }) => db.deleteLearningResource(input.id, ctx.user.id)),
  }),

  // ============ ROADMAP FEATURES ============
  roadmapFeatures: router({
    list: protectedProcedure.query(({ ctx }) => db.getUserRoadmapFeatures(ctx.user.id)),
    
    create: protectedProcedure
      .input(z.object({
        featureName: z.string().min(1),
        description: z.string().optional(),
        mvpPriority: z.enum(["Critical", "High", "Medium", "Low"]).default("Medium"),
        status: z.enum(["Not Started", "In Progress", "Completed"]).default("Not Started"),
        complexity: z.enum(["Low", "Medium", "High"]).default("Medium"),
        notes: z.string().optional(),
      }))
      .mutation(({ ctx, input }) => db.createRoadmapFeature(ctx.user.id, input)),

    update: protectedProcedure
      .input(z.object({
        id: z.number(),
        featureName: z.string().min(1).optional(),
        description: z.string().optional(),
        mvpPriority: z.enum(["Critical", "High", "Medium", "Low"]).optional(),
        status: z.enum(["Not Started", "In Progress", "Completed"]).optional(),
        complexity: z.enum(["Low", "Medium", "High"]).optional(),
        notes: z.string().optional(),
      }))
      .mutation(({ ctx, input }) => {
        const { id, ...data } = input;
        return db.updateRoadmapFeature(id, ctx.user.id, data);
      }),

    delete: protectedProcedure
      .input(z.object({ id: z.number() }))
      .mutation(({ ctx, input }) => db.deleteRoadmapFeature(input.id, ctx.user.id)),
  }),

  // ============ PROMPTS ============
  prompts: router({
    list: protectedProcedure.query(({ ctx }) => db.getUserPrompts(ctx.user.id)),
    
    create: protectedProcedure
      .input(z.object({
        title: z.string().min(1),
        category: z.enum(["Manus", "ChatGPT", "Lovable", "Zapier", "Make", "GoHighLevel"]),
        promptText: z.string().min(1),
        tags: z.string().optional(),
      }))
      .mutation(({ ctx, input }) => db.createPrompt(ctx.user.id, input)),

    update: protectedProcedure
      .input(z.object({
        id: z.number(),
        title: z.string().min(1).optional(),
        category: z.enum(["Manus", "ChatGPT", "Lovable", "Zapier", "Make", "GoHighLevel"]).optional(),
        promptText: z.string().min(1).optional(),
        tags: z.string().optional(),
      }))
      .mutation(({ ctx, input }) => {
        const { id, ...data } = input;
        return db.updatePrompt(id, ctx.user.id, data);
      }),

    delete: protectedProcedure
      .input(z.object({ id: z.number() }))
      .mutation(({ ctx, input }) => db.deletePrompt(input.id, ctx.user.id)),
  }),

  // ============ STUDY SESSIONS ============
  studySessions: router({
    list: protectedProcedure.query(({ ctx }) => db.getUserStudySessions(ctx.user.id)),
    
    create: protectedProcedure
      .input(z.object({
        dayOfWeek: z.enum(["Monday", "Tuesday", "Wednesday", "Thursday", "Friday"]),
        startTime: z.string().regex(/^\d{2}:\d{2}$/),
        endTime: z.string().regex(/^\d{2}:\d{2}$/),
        subject: z.string().min(1),
        status: z.enum(["Scheduled", "In Progress", "Completed", "Skipped"]).default("Scheduled"),
        notes: z.string().optional(),
      }))
      .mutation(({ ctx, input }) => db.createStudySession(ctx.user.id, input)),

    update: protectedProcedure
      .input(z.object({
        id: z.number(),
        dayOfWeek: z.enum(["Monday", "Tuesday", "Wednesday", "Thursday", "Friday"]).optional(),
        startTime: z.string().regex(/^\d{2}:\d{2}$/).optional(),
        endTime: z.string().regex(/^\d{2}:\d{2}$/).optional(),
        subject: z.string().min(1).optional(),
        status: z.enum(["Scheduled", "In Progress", "Completed", "Skipped"]).optional(),
        notes: z.string().optional(),
      }))
      .mutation(({ ctx, input }) => {
        const { id, ...data } = input;
        return db.updateStudySession(id, ctx.user.id, data);
      }),

    delete: protectedProcedure
      .input(z.object({ id: z.number() }))
      .mutation(({ ctx, input }) => db.deleteStudySession(input.id, ctx.user.id)),
  }),

  // ============ DASHBOARD ============
  dashboard: router({
    summary: protectedProcedure.query(async ({ ctx }) => {
      const summary = await db.getDashboardSummary(ctx.user.id);
      const subscriptions = await db.getUserSubscriptions(ctx.user.id);
      const roadmapFeatures = await db.getUserRoadmapFeatures(ctx.user.id);
      
      const activeCount = subscriptions.filter(s => s.status === "Active").length;
      const trialCount = subscriptions.filter(s => s.status === "Trial").length;
      const completedFeatures = roadmapFeatures.filter(f => f.status === "Completed").length;
      const totalFeatures = roadmapFeatures.length;
      const mvpProgress = totalFeatures > 0 ? Math.round((completedFeatures / totalFeatures) * 100) : 0;

      return {
        weeklyFocus: summary?.weeklyFocus || "",
        currentPriorities: summary?.currentPriorities || "",
        activeSubscriptionsCount: activeCount,
        upcomingTrialExpirations: trialCount,
        mvpProgressPercentage: mvpProgress,
      };
    }),

    updateSummary: protectedProcedure
      .input(z.object({
        weeklyFocus: z.string().optional(),
        currentPriorities: z.string().optional(),
      }))
      .mutation(({ ctx, input }) => {
        return db.upsertDashboardSummary(ctx.user.id, {
          weeklyFocus: input.weeklyFocus,
          currentPriorities: input.currentPriorities,
        });
      }),
  }),

  // ============ LEARNING MODULES ============
  learningModules: router({
    // Get all phases for user
    phases: protectedProcedure.query(({ ctx }) => db.getUserPhases(ctx.user.id)),

    // Get specific phase with all related data
    getPhase: protectedProcedure
      .input(z.object({ phaseId: z.number() }))
      .query(async ({ ctx, input }) => {
        const phase = await db.getPhaseById(input.phaseId, ctx.user.id);
        if (!phase) return null;
        
        const resources = await db.getPhaseResources(input.phaseId, ctx.user.id);
        const notes = await db.getPhaseNotes(input.phaseId, ctx.user.id);
        const progress = await db.getPhaseProgress(input.phaseId, ctx.user.id);
        
        return {
          phase,
          resources,
          notes,
          progress,
        };
      }),

    // Update phase
    updatePhase: protectedProcedure
      .input(z.object({
        phaseId: z.number(),
        title: z.string().optional(),
        description: z.string().optional(),
        topics: z.string().optional(),
        goals: z.string().optional(),
        keyConceptsContent: z.string().optional(),
        learningOutline: z.string().optional(),
        status: z.enum(["Not Started", "In Progress", "Completed"]).optional(),
        completionPercentage: z.number().optional(),
      }))
      .mutation(({ ctx, input }) => {
        const { phaseId, ...data } = input;
        return db.updatePhase(phaseId, ctx.user.id, data);
      }),

    // Add resource to phase
    addResource: protectedProcedure
      .input(z.object({
        phaseId: z.number(),
        resourceType: z.enum(["Video", "Article", "Link", "Document"]),
        title: z.string().min(1),
        url: z.string().url(),
        description: z.string().optional(),
        duration: z.number().optional(),
      }))
      .mutation(({ ctx, input }) => {
        return db.createPhaseResource(ctx.user.id, input);
      }),

    // Delete resource
    deleteResource: protectedProcedure
      .input(z.object({ resourceId: z.number() }))
      .mutation(({ ctx, input }) => db.deletePhaseResource(input.resourceId, ctx.user.id)),

    // Update phase notes
    updateNotes: protectedProcedure
      .input(z.object({
        phaseId: z.number(),
        personalNotes: z.string().optional(),
        whatILearned: z.string().optional(),
        keyTakeaways: z.string().optional(),
        whatToRevisit: z.string().optional(),
        customReflections: z.string().optional(),
      }))
      .mutation(({ ctx, input }) => {
        const { phaseId, ...data } = input;
        return db.updatePhaseNotes(phaseId, ctx.user.id, data);
      }),

    // Update phase progress
    updateProgress: protectedProcedure
      .input(z.object({
        phaseId: z.number(),
        status: z.enum(["Not Started", "In Progress", "Completed"]).optional(),
        completionPercentage: z.number().optional(),
        timeSpentMinutes: z.number().optional(),
        resourcesAdded: z.number().optional(),
        notesCount: z.number().optional(),
      }))
      .mutation(({ ctx, input }) => {
        const { phaseId, ...data } = input;
        return db.updatePhaseProgress(phaseId, ctx.user.id, data);
      }),
  }),
});

export type AppRouter = typeof appRouter;
