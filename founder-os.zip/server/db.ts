import { eq, and, desc } from "drizzle-orm";
import { drizzle } from "drizzle-orm/mysql2";
import { InsertUser, users, subscriptions, learningResources, roadmapFeatures, prompts, studySessions, dashboardSummary, learningPhases, phaseResources, phaseNotes, phaseProgress } from "../drizzle/schema";
import { ENV } from './_core/env';

let _db: ReturnType<typeof drizzle> | null = null;

// Lazily create the drizzle instance so local tooling can run without a DB.
export async function getDb() {
  if (!_db && process.env.DATABASE_URL) {
    try {
      _db = drizzle(process.env.DATABASE_URL);
    } catch (error) {
      console.warn("[Database] Failed to connect:", error);
      _db = null;
    }
  }
  return _db;
}

export async function upsertUser(user: InsertUser): Promise<void> {
  if (!user.openId) {
    throw new Error("User openId is required for upsert");
  }

  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot upsert user: database not available");
    return;
  }

  try {
    const values: InsertUser = {
      openId: user.openId,
    };
    const updateSet: Record<string, unknown> = {};

    const textFields = ["name", "email", "loginMethod"] as const;
    type TextField = (typeof textFields)[number];

    const assignNullable = (field: TextField) => {
      const value = user[field];
      if (value === undefined) return;
      const normalized = value ?? null;
      values[field] = normalized;
      updateSet[field] = normalized;
    };

    textFields.forEach(assignNullable);

    if (user.lastSignedIn !== undefined) {
      values.lastSignedIn = user.lastSignedIn;
      updateSet.lastSignedIn = user.lastSignedIn;
    }
    if (user.role !== undefined) {
      values.role = user.role;
      updateSet.role = user.role;
    } else if (user.openId === ENV.ownerOpenId) {
      values.role = 'admin';
      updateSet.role = 'admin';
    }

    if (!values.lastSignedIn) {
      values.lastSignedIn = new Date();
    }

    if (Object.keys(updateSet).length === 0) {
      updateSet.lastSignedIn = new Date();
    }

    await db.insert(users).values(values).onDuplicateKeyUpdate({
      set: updateSet,
    });
  } catch (error) {
    console.error("[Database] Failed to upsert user:", error);
    throw error;
  }
}

export async function getUserByOpenId(openId: string) {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot get user: database not available");
    return undefined;
  }

  const result = await db.select().from(users).where(eq(users.openId, openId)).limit(1);

  return result.length > 0 ? result[0] : undefined;
}

// ============ SUBSCRIPTIONS ============

export async function getUserSubscriptions(userId: number) {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(subscriptions).where(eq(subscriptions.userId, userId)).orderBy(desc(subscriptions.createdAt));
}

export async function createSubscription(userId: number, data: Omit<typeof subscriptions.$inferInsert, 'userId'>) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  const result = await db.insert(subscriptions).values({ ...data, userId });
  return result;
}

export async function updateSubscription(id: number, userId: number, data: Partial<typeof subscriptions.$inferInsert>) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  return db.update(subscriptions).set(data).where(and(eq(subscriptions.id, id), eq(subscriptions.userId, userId)));
}

export async function deleteSubscription(id: number, userId: number) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  return db.delete(subscriptions).where(and(eq(subscriptions.id, id), eq(subscriptions.userId, userId)));
}

// ============ LEARNING RESOURCES ============

export async function getUserLearningResources(userId: number) {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(learningResources).where(eq(learningResources.userId, userId)).orderBy(desc(learningResources.createdAt));
}

export async function createLearningResource(userId: number, data: Omit<typeof learningResources.$inferInsert, 'userId'>) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  return db.insert(learningResources).values({ ...data, userId });
}

export async function updateLearningResource(id: number, userId: number, data: Partial<typeof learningResources.$inferInsert>) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  return db.update(learningResources).set(data).where(and(eq(learningResources.id, id), eq(learningResources.userId, userId)));
}

export async function deleteLearningResource(id: number, userId: number) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  return db.delete(learningResources).where(and(eq(learningResources.id, id), eq(learningResources.userId, userId)));
}

// ============ ROADMAP FEATURES ============

export async function getUserRoadmapFeatures(userId: number) {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(roadmapFeatures).where(eq(roadmapFeatures.userId, userId)).orderBy(desc(roadmapFeatures.createdAt));
}

export async function createRoadmapFeature(userId: number, data: Omit<typeof roadmapFeatures.$inferInsert, 'userId'>) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  return db.insert(roadmapFeatures).values({ ...data, userId });
}

export async function updateRoadmapFeature(id: number, userId: number, data: Partial<typeof roadmapFeatures.$inferInsert>) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  return db.update(roadmapFeatures).set(data).where(and(eq(roadmapFeatures.id, id), eq(roadmapFeatures.userId, userId)));
}

export async function deleteRoadmapFeature(id: number, userId: number) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  return db.delete(roadmapFeatures).where(and(eq(roadmapFeatures.id, id), eq(roadmapFeatures.userId, userId)));
}

// ============ PROMPTS ============

export async function getUserPrompts(userId: number) {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(prompts).where(eq(prompts.userId, userId)).orderBy(desc(prompts.createdAt));
}

export async function createPrompt(userId: number, data: Omit<typeof prompts.$inferInsert, 'userId'>) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  return db.insert(prompts).values({ ...data, userId });
}

export async function updatePrompt(id: number, userId: number, data: Partial<typeof prompts.$inferInsert>) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  return db.update(prompts).set(data).where(and(eq(prompts.id, id), eq(prompts.userId, userId)));
}

export async function deletePrompt(id: number, userId: number) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  return db.delete(prompts).where(and(eq(prompts.id, id), eq(prompts.userId, userId)));
}

// ============ STUDY SESSIONS ============

export async function getUserStudySessions(userId: number) {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(studySessions).where(eq(studySessions.userId, userId)).orderBy(desc(studySessions.createdAt));
}

export async function createStudySession(userId: number, data: Omit<typeof studySessions.$inferInsert, 'userId'>) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  return db.insert(studySessions).values({ ...data, userId });
}

export async function updateStudySession(id: number, userId: number, data: Partial<typeof studySessions.$inferInsert>) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  return db.update(studySessions).set(data).where(and(eq(studySessions.id, id), eq(studySessions.userId, userId)));
}

export async function deleteStudySession(id: number, userId: number) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  return db.delete(studySessions).where(and(eq(studySessions.id, id), eq(studySessions.userId, userId)));
}

// ============ DASHBOARD SUMMARY ============

export async function getDashboardSummary(userId: number) {
  const db = await getDb();
  if (!db) return null;
  const result = await db.select().from(dashboardSummary).where(eq(dashboardSummary.userId, userId)).limit(1);
  return result.length > 0 ? result[0] : null;
}

export async function upsertDashboardSummary(userId: number, data: Omit<typeof dashboardSummary.$inferInsert, 'userId'>) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  return db.insert(dashboardSummary).values({ ...data, userId }).onDuplicateKeyUpdate({
    set: data,
  });
}


// ============ LEARNING PHASES ============

export async function getPhaseById(phaseId: number, userId: number) {
  const db = await getDb();
  if (!db) return null;
  const result = await db.select().from(learningPhases).where(and(eq(learningPhases.id, phaseId), eq(learningPhases.userId, userId))).limit(1);
  return result.length > 0 ? result[0] : null;
}

export async function getUserPhases(userId: number) {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(learningPhases).where(eq(learningPhases.userId, userId)).orderBy(learningPhases.phaseNumber);
}

export async function createPhase(userId: number, data: Omit<typeof learningPhases.$inferInsert, 'userId'>) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  return db.insert(learningPhases).values({ ...data, userId });
}

export async function updatePhase(phaseId: number, userId: number, data: Partial<typeof learningPhases.$inferInsert>) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  return db.update(learningPhases).set(data).where(and(eq(learningPhases.id, phaseId), eq(learningPhases.userId, userId)));
}

// ============ PHASE RESOURCES ============

export async function getPhaseResources(phaseId: number, userId: number) {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(phaseResources).where(and(eq(phaseResources.phaseId, phaseId), eq(phaseResources.userId, userId))).orderBy(desc(phaseResources.addedAt));
}

export async function createPhaseResource(userId: number, data: Omit<typeof phaseResources.$inferInsert, 'userId'>) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  return db.insert(phaseResources).values({ ...data, userId });
}

export async function updatePhaseResource(resourceId: number, userId: number, data: Partial<typeof phaseResources.$inferInsert>) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  return db.update(phaseResources).set(data).where(and(eq(phaseResources.id, resourceId), eq(phaseResources.userId, userId)));
}

export async function deletePhaseResource(resourceId: number, userId: number) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  return db.delete(phaseResources).where(and(eq(phaseResources.id, resourceId), eq(phaseResources.userId, userId)));
}

// ============ PHASE NOTES ============

export async function getPhaseNotes(phaseId: number, userId: number) {
  const db = await getDb();
  if (!db) return null;
  const result = await db.select().from(phaseNotes).where(and(eq(phaseNotes.phaseId, phaseId), eq(phaseNotes.userId, userId))).limit(1);
  return result.length > 0 ? result[0] : null;
}

export async function createPhaseNotes(userId: number, data: Omit<typeof phaseNotes.$inferInsert, 'userId'>) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  return db.insert(phaseNotes).values({ ...data, userId });
}

export async function updatePhaseNotes(phaseId: number, userId: number, data: Partial<typeof phaseNotes.$inferInsert>) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  const existing = await getPhaseNotes(phaseId, userId);
  if (existing) {
    return db.update(phaseNotes).set(data).where(and(eq(phaseNotes.phaseId, phaseId), eq(phaseNotes.userId, userId)));
  } else {
    return db.insert(phaseNotes).values({ ...data, phaseId, userId });
  }
}

// ============ PHASE PROGRESS ============

export async function getPhaseProgress(phaseId: number, userId: number) {
  const db = await getDb();
  if (!db) return null;
  const result = await db.select().from(phaseProgress).where(and(eq(phaseProgress.phaseId, phaseId), eq(phaseProgress.userId, userId))).limit(1);
  return result.length > 0 ? result[0] : null;
}

export async function createPhaseProgress(userId: number, data: Omit<typeof phaseProgress.$inferInsert, 'userId'>) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  return db.insert(phaseProgress).values({ ...data, userId });
}

export async function updatePhaseProgress(phaseId: number, userId: number, data: Partial<typeof phaseProgress.$inferInsert>) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  const existing = await getPhaseProgress(phaseId, userId);
  if (existing) {
    return db.update(phaseProgress).set(data).where(and(eq(phaseProgress.phaseId, phaseId), eq(phaseProgress.userId, userId)));
  } else {
    return db.insert(phaseProgress).values({ ...data, phaseId, userId });
  }
}
